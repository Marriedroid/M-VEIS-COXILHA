/* Formatação, máscaras e validações (padrões brasileiros). */
(function () {
  const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  const digits = (s) => String(s || '').replace(/\D/g, '');

  const U = {
    digits,
    money: (n) => brl.format(Number(n) || 0).replace(/ /g, ' '),
    esc: (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    norm: (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim(),
    qs: (k) => new URLSearchParams(location.search).get(k),
    debounce: (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; },

    // ----- máscaras -----
    maskCPF: (v) => digits(v).slice(0, 11).replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2'),
    maskPhone: (v) => {
      const d = digits(v).slice(0, 11);
      if (d.length <= 2) return d ? '(' + d : '';
      if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
      if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
      return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
    },
    maskCEP: (v) => { const d = digits(v).slice(0, 8); return d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d; },
    maskCard: (v) => digits(v).slice(0, 19).replace(/(\d{4})(?=\d)/g, '$1 '),
    maskExpiry: (v) => { const d = digits(v).slice(0, 4); return d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d; },

    // ----- validações -----
    isEmail: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v).trim()),
    isCEP: (v) => digits(v).length === 8,
    isPhone: (v) => { const d = digits(v); return (d.length === 10 || d.length === 11) && +d.slice(0, 2) >= 11 && (d.length === 10 || d[2] === '9'); },
    isCPF: (v) => {
      const c = digits(v);
      if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;
      const calc = (len) => { let s = 0; for (let i = 0; i < len; i++) s += +c[i] * (len + 1 - i); const r = (s * 10) % 11; return r === 10 ? 0 : r; };
      return calc(9) === +c[9] && calc(10) === +c[10];
    },
    isCard: (v) => {            // algoritmo de Luhn
      const d = digits(v); if (d.length < 13 || d.length > 19) return false;
      let sum = 0, alt = false;
      for (let i = d.length - 1; i >= 0; i--) { let n = +d[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; }
      return sum % 10 === 0;
    },
    isExpiry: (v) => {
      const m = /^(\d{2})\/(\d{2})$/.exec(v); if (!m) return false;
      const mo = +m[1], yr = 2000 + +m[2]; if (mo < 1 || mo > 12) return false;
      const now = new Date(); return yr > now.getFullYear() || (yr === now.getFullYear() && mo >= now.getMonth() + 1);
    },
    isCVV: (v) => /^\d{3,4}$/.test(v)
  };

  /* Aplica máscaras declaradas em data-mask="cpf|phone|cep|card|expiry" */
  U.bindMasks = (root = document) => {
    const map = { cpf: U.maskCPF, phone: U.maskPhone, cep: U.maskCEP, card: U.maskCard, expiry: U.maskExpiry };
    root.querySelectorAll('[data-mask]').forEach((el) => {
      if (el.dataset.maskBound) return; el.dataset.maskBound = '1';
      const fn = map[el.dataset.mask];
      el.addEventListener('input', () => { el.value = fn(el.value); });
    });
  };

  /*
   * Validação declarativa de formulários.
   * rules = { campo: [ (valor, form) => 'mensagem de erro' | '' ] }
   * Mostra a mensagem no elemento [data-error-for="campo"] e marca aria-invalid.
   */
  U.validate = (form, rules) => {
    let first = null, ok = true;
    for (const [name, checks] of Object.entries(rules)) {
      const el = form.elements[name]; if (!el) continue;
      const val = el.type === 'checkbox' ? el.checked : String(el.value || '').trim();
      let msg = '';
      for (const c of checks) { msg = c(val, form); if (msg) break; }
      U.setError(form, name, msg);
      if (msg) { ok = false; first = first || el; }
    }
    if (first) first.focus();
    return ok;
  };
  U.setError = (form, name, msg) => {
    const el = form.elements[name]; const box = form.querySelector(`[data-error-for="${name}"]`);
    if (el) { if (msg) el.setAttribute('aria-invalid', 'true'); else el.removeAttribute('aria-invalid'); }
    if (box) { box.textContent = msg || ''; box.hidden = !msg; }
  };
  U.clearErrors = (form) => {
    form.querySelectorAll('[data-error-for]').forEach((b) => { b.textContent = ''; b.hidden = true; });
    form.querySelectorAll('[aria-invalid]').forEach((e) => e.removeAttribute('aria-invalid'));
  };
  // Regras reutilizáveis
  U.r = {
    required: (m = 'Preencha este campo.') => (v) => (v === true || (v !== false && v !== '') ? '' : m),
    email: () => (v) => (v && !U.isEmail(v) ? 'Informe um e-mail válido, como nome@exemplo.com.' : ''),
    cpf: () => (v) => (v && !U.isCPF(v) ? 'CPF inválido. Confira os 11 números.' : ''),
    phone: () => (v) => (v && !U.isPhone(v) ? 'Informe o celular com DDD, ex.: (11) 99999-0000.' : ''),
    cep: () => (v) => (v && !U.isCEP(v) ? 'CEP inválido. Use 8 números.' : ''),
    min: (n, m) => (v) => (v && v.length < n ? m || `Use ao menos ${n} caracteres.` : ''),
    name: () => (v) => (v && (v.length < 3 || !/\s/.test(v)) ? 'Informe nome e sobrenome.' : '')
  };

  window.U = U;
})();
