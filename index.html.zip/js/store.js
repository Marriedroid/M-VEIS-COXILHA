/*
 * Camada de dados da loja. Mesma interface em dois modos:
 *  - 'supabase': usa a API REST do Supabase (config.supabase preenchido)
 *  - 'local'   : usa localStorage + js/seed-data.js (para testar sem banco)
 */
(function () {
  const CFG = window.COXILHA_CONFIG;
  const SEED = window.COXILHA_SEED;
  const SB = CFG.supabase.url && CFG.supabase.anonKey ? CFG.supabase : null;
  const mode = SB ? 'supabase' : 'local';

  const ls = {
    get: (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* armazenamento indisponível */ } },
    del: (k) => { try { localStorage.removeItem(k); } catch { /* idem */ } }
  };
  const emit = (name, detail) => window.dispatchEvent(new CustomEvent(name, { detail }));

  /* ------------------------------------------------------------ Supabase REST */
  let session = ls.get('coxilha.sb', null);

  async function sb(path, { method = 'GET', body, headers = {}, token } = {}) {
    const bearer = token || (session && session.access_token) || SB.anonKey;
    let res;
    try {
      res = await fetch(SB.url.replace(/\/$/, '') + path, {
        method, body: body === undefined ? undefined : JSON.stringify(body),
        headers: { apikey: SB.anonKey, Authorization: 'Bearer ' + bearer, 'Content-Type': 'application/json', ...headers }
      });
    } catch { throw new Error('Sem conexão com o servidor. Verifique sua internet e tente novamente.'); }
    if (res.status === 204) return null;
    const txt = await res.text(); let data = null;
    try { data = txt ? JSON.parse(txt) : null; } catch { data = txt; }
    if (!res.ok) {
      const err = new Error((data && (data.msg || data.message || data.error_description || data.error)) || 'Erro ao falar com o servidor.');
      err.status = res.status; err.code = data && data.code; throw err;
    }
    return data;
  }

  async function ensureFreshSession() {
    if (!SB || !session) return;
    if (session.expires_at && session.expires_at * 1000 - Date.now() < 60000) {
      try {
        const d = await sb('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: session.refresh_token }, token: SB.anonKey });
        saveSession(d);
      } catch { session = null; ls.del('coxilha.sb'); }
    }
  }
  function saveSession(d) {
    session = { access_token: d.access_token, refresh_token: d.refresh_token, expires_at: d.expires_at || Math.floor(Date.now() / 1000) + (d.expires_in || 3600), user: d.user };
    ls.set('coxilha.sb', session);
  }

  /* ------------------------------------------------------------ Catálogo */
  let catalogCache = null;

  function fromSeed() {
    const cats = SEED.categories.map((c) => ({ ...c, id: c.slug }));
    const products = SEED.products.map((p) => ({
      id: p.slug, slug: p.slug, category: cats.find((c) => c.slug === p.category), name: p.name, subtitle: p.subtitle, kicker: p.kicker,
      description: p.description, detail_title: p.detail_title, detail_text: p.detail_text, image: p.image, home_image: p.home_image || p.image, gallery: p.gallery,
      detail_image: p.detail_image, specs: p.specs, max_dimension_cm: p.max_dimension_cm, installments: p.installments,
      lead_time_days: p.lead_time_days, featured: !!p.featured,
      variants: p.variants.map((v, i) => ({ id: `${p.slug}-v${i + 1}`, ...v }))
    }));
    return { categories: cats, products };
  }

  async function loadCatalog() {
    if (catalogCache) return catalogCache;
    if (mode === 'local') return (catalogCache = fromSeed());
    const [cats, prods] = await Promise.all([
      sb('/rest/v1/categories?select=*&order=sort_order').then((r) => r.map((c) => ({ ...c, image: c.image_url }))),
      sb('/rest/v1/products?select=*,categories(id,slug,name,short_name),product_variants(*)&active=eq.true&order=created_at')
    ]);
    const products = prods.map((p) => ({
      id: p.id, slug: p.slug, category: p.categories, name: p.name, subtitle: p.subtitle, kicker: p.kicker, description: p.description,
      detail_title: p.detail_title, detail_text: p.detail_text, image: p.image_url, home_image: p.home_image_url || p.image_url, gallery: p.gallery || [], detail_image: p.detail_image_url,
      specs: p.specs || [], max_dimension_cm: p.max_dimension_cm, installments: p.installments, lead_time_days: p.lead_time_days, featured: p.featured,
      variants: (p.product_variants || []).filter((v) => v.active !== false).sort((a, b) => a.sort_order - b.sort_order).map((v) => ({ ...v, price: Number(v.price) }))
    })).filter((p) => p.variants.length);
    return (catalogCache = { categories: cats, products });
  }

  const minPrice = (p) => Math.min(...p.variants.map((v) => v.price));
  const PRICE_RANGES = { ate1000: [0, 1000], de1000a2000: [1000.01, 2000], acima2000: [2000.01, Infinity] };
  const WIDTH_RANGES = { ate100: [0, 100], de101a150: [101, 150], acima150: [151, Infinity] };

  const Store = {
    mode, PRICE_RANGES, WIDTH_RANGES, minPrice,

    categories: async () => (await loadCatalog()).categories,
    allProducts: async () => (await loadCatalog()).products,

    /* filtros: { q, category:[slugs], price:[keys], width:[keys], wood:[names], sort } */
    async products(f = {}) {
      let list = [...(await loadCatalog()).products];
      if (f.q) {
        const terms = U.norm(f.q).split(/\s+/).filter(Boolean);
        list = list.filter((p) => { const hay = U.norm([p.name, p.subtitle, p.description, p.category && p.category.name, ...p.variants.map((v) => v.wood)].join(' ')); return terms.every((t) => hay.includes(t)); });
      }
      if (f.category && f.category.length) list = list.filter((p) => p.category && f.category.includes(p.category.slug));
      if (f.price && f.price.length) list = list.filter((p) => f.price.some((k) => { const [a, b] = PRICE_RANGES[k]; const m = minPrice(p); return m >= a && m <= b; }));
      if (f.width && f.width.length) list = list.filter((p) => f.width.some((k) => { const [a, b] = WIDTH_RANGES[k]; return p.max_dimension_cm >= a && p.max_dimension_cm <= b; }));
      if (f.wood && f.wood.length) list = list.filter((p) => p.variants.some((v) => f.wood.includes(v.wood)));
      const sorts = {
        destaques: (a, b) => (b.featured - a.featured), 'menor-preco': (a, b) => minPrice(a) - minPrice(b),
        'maior-preco': (a, b) => minPrice(b) - minPrice(a), nome: (a, b) => a.name.localeCompare(b.name, 'pt-BR')
      };
      return list.sort(sorts[f.sort] || sorts.destaques);
    },
    async product(slug) { return (await loadCatalog()).products.find((p) => p.slug === slug) || null; },
    async related(product, n = 3) {
      const all = (await loadCatalog()).products.filter((p) => p.slug !== product.slug);
      all.sort((a, b) => (b.category?.slug === product.category?.slug) - (a.category?.slug === product.category?.slug) || b.featured - a.featured);
      return all.slice(0, n);
    },

    /* ------------------------------------------------------------ Autenticação */
    auth: {
      async user() {
        if (mode === 'supabase') {
          await ensureFreshSession();
          if (!session) return null;
          const u = session.user || {}; const m = u.user_metadata || {};
          return { id: u.id, email: u.email, name: m.full_name || (u.email || '').split('@')[0], cpf: m.cpf || '', phone: m.phone || '' };
        }
        return ls.get('coxilha.session', null);
      },
      async signUp({ name, email, password, cpf, phone }) {
        email = email.trim().toLowerCase();
        if (mode === 'supabase') {
          const d = await sb('/auth/v1/signup', { method: 'POST', token: SB.anonKey, body: { email, password, data: { full_name: name, cpf, phone } } });
          if (d && d.access_token) { saveSession(d); await Store.favorites.mergeLocal(); emit('auth:change'); return { needsConfirmation: false }; }
          return { needsConfirmation: true };
        }
        const users = ls.get('coxilha.users', {});
        if (users[email]) throw new Error('Já existe uma conta com este e-mail. Entre com sua senha.');
        users[email] = { id: 'u_' + Date.now().toString(36), name, email, cpf, phone, hash: await hash(password) };
        ls.set('coxilha.users', users);
        const { hash: _h, ...pub } = users[email]; ls.set('coxilha.session', pub);
        emit('auth:change'); return { needsConfirmation: false };
      },
      async signIn({ email, password }) {
        email = email.trim().toLowerCase();
        if (mode === 'supabase') {
          let d;
          try { d = await sb('/auth/v1/token?grant_type=password', { method: 'POST', token: SB.anonKey, body: { email, password } }); }
          catch (e) { throw new Error(/invalid|credentials/i.test(e.message) ? 'E-mail ou senha incorretos.' : /confirm/i.test(e.message) ? 'Confirme seu e-mail antes de entrar. Enviamos um link para a sua caixa de entrada.' : e.message); }
          saveSession(d); await Store.favorites.mergeLocal(); emit('auth:change'); return;
        }
        const u = ls.get('coxilha.users', {})[email];
        if (!u || u.hash !== (await hash(password))) throw new Error('E-mail ou senha incorretos.');
        const { hash: _h, ...pub } = u; ls.set('coxilha.session', pub); emit('auth:change');
      },
      async signOut() {
        if (mode === 'supabase') { try { await sb('/auth/v1/logout', { method: 'POST' }); } catch { /* sessão já expirada */ } session = null; ls.del('coxilha.sb'); }
        else ls.del('coxilha.session');
        emit('auth:change');
      }
    },

    /* ------------------------------------------------------------ Favoritos */
    favorites: {
      local: () => ls.get('coxilha.favs', []),
      async ids() {
        const u = await Store.auth.user();
        if (mode === 'supabase' && u) { try { return (await sb('/rest/v1/favorites?select=product_id')).map((r) => r.product_id); } catch { return Store.favorites.local(); } }
        return Store.favorites.local();
      },
      async toggle(productId) {
        const u = await Store.auth.user();
        const has = (await Store.favorites.ids()).includes(productId);
        if (mode === 'supabase' && u) {
          if (has) await sb(`/rest/v1/favorites?product_id=eq.${productId}`, { method: 'DELETE' });
          else await sb('/rest/v1/favorites', { method: 'POST', headers: { Prefer: 'return=minimal,resolution=ignore-duplicates' }, body: { customer_id: u.id, product_id: productId } });
        } else {
          const l = Store.favorites.local(); ls.set('coxilha.favs', has ? l.filter((i) => i !== productId) : [...l, productId]);
        }
        emit('favorites:change', { productId, active: !has }); return !has;
      },
      async mergeLocal() {   // ao entrar, leva os favoritos de visitante para a conta
        const u = await Store.auth.user(); const l = Store.favorites.local();
        if (mode === 'supabase' && u && l.length) {
          try { await sb('/rest/v1/favorites', { method: 'POST', headers: { Prefer: 'return=minimal,resolution=ignore-duplicates' }, body: l.map((id) => ({ customer_id: u.id, product_id: id })) }); ls.del('coxilha.favs'); } catch { /* mantém local */ }
        }
      }
    },

    /* ------------------------------------------------------------ Frete */
    async shippingQuote(cepInput) {
      const cep = U.digits(cepInput);
      if (cep.length !== 8) throw new Error('Informe um CEP com 8 números.');
      let addr = null;
      try {
        const r = await fetch(CFG.cepLookupUrl.replace('{cep}', cep));
        const j = await r.json(); if (j && !j.erro) addr = { street: j.logradouro, district: j.bairro, city: j.localidade, uf: j.uf };
        else if (j && j.erro) throw new Error('CEP não encontrado. Confira os números e tente novamente.');
      } catch (e) { if (/CEP não/.test(e.message)) throw e; /* consulta indisponível: segue só com a faixa do CEP */ }
      const uf = addr ? addr.uf : (+cep.slice(0, 5) >= 1000 && +cep.slice(0, 5) <= 19999 ? 'SP' : null);
      let rate = null;
      if (mode === 'supabase') {
        const rows = await sb('/rest/v1/shipping_rates?select=*');
        rate = rows.find((r) => r.uf === uf) || rows.find((r) => r.uf === 'DEFAULT');
        if (rate) rate = { price: Number(rate.price) };
      } else {
        const rr = CFG.shipping.localRates; rate = { price: rr[uf] ?? rr.DEFAULT };
      }
      if (!rate) throw new Error('Ainda não calculamos frete para esta região. Fale com a oficina.');
      return { cep, uf, city: addr?.city || (uf === 'SP' ? 'São Paulo' : ''), street: addr?.street || '', district: addr?.district || '', price: rate.price,
        prodDays: CFG.shipping.productionDaysMax, transpDays: CFG.shipping.transportDaysMax };
    },
    savedCep: () => ls.get('coxilha.cep', null),
    saveCep: (q) => ls.set('coxilha.cep', q),

    /* ------------------------------------------------------------ Cupom e totais */
    async coupon(code, subtotal) {
      code = String(code || '').trim().toUpperCase();
      if (!code) throw new Error('Digite o código do cupom.');
      if (mode === 'supabase') {
        try { const r = await sb('/rest/v1/rpc/apply_coupon', { method: 'POST', body: { p_code: code, p_subtotal: subtotal } }); return { code: r.code, discount: Number(r.discount) }; }
        catch (e) { throw new Error(e.message || 'Cupom inválido ou expirado.'); }
      }
      const c = CFG.localCoupons && CFG.localCoupons[code];
      if (!c) throw new Error('Cupom inválido ou expirado.');
      if (subtotal < (c.min || 0)) throw new Error(`Este cupom vale para compras a partir de ${U.money(c.min)}.`);
      return { code, discount: c.kind === 'percent' ? Math.round(subtotal * c.value) / 100 : Math.min(c.value, subtotal) };
    },
    savedCoupon: () => ls.get('coxilha.coupon', null),
    saveCoupon: (c) => (c ? ls.set('coxilha.coupon', c) : ls.del('coxilha.coupon')),
    totals(lines, quote, coupon) {
      const subtotal = Cart.subtotal(lines); const shipping = quote ? quote.price : null; const discount = coupon ? Math.min(coupon.discount, subtotal) : 0;
      const total = subtotal - discount + (shipping || 0); const n = CFG.payment.maxInstallments;
      return { subtotal, shipping, discount, total, installments: n, installment: total / n };
    },

    /* ------------------------------------------------------------ Pedidos */
    async createOrder(payload) {
      if (mode === 'supabase') {
        await ensureFreshSession();
        const r = await sb('/rest/v1/rpc/create_order', { method: 'POST', body: { payload } });
        return r;
      }
      const cat = await loadCatalog(); let subtotal = 0; const items = [];
      for (const it of payload.items) {
        const p = cat.products.find((x) => x.variants.some((v) => v.id === it.variant_id)); if (!p) throw new Error('Produto indisponível.');
        const v = p.variants.find((x) => x.id === it.variant_id); subtotal += v.price * it.quantity;
        items.push({ product_name: p.name, variant_label: `${v.wood} · ${v.dimensions}`, unit_price: v.price, quantity: it.quantity });
      }
      const rr = CFG.shipping.localRates; const ship = rr[payload.address.state] ?? rr.DEFAULT;
      const disc = payload.coupon ? (await Store.coupon(payload.coupon, subtotal)).discount : 0;
      const orders = ls.get('coxilha.orders', []); const number = 'CX-' + (1001 + orders.length);
      const u = await Store.auth.user();
      const order = { id: 'o_' + Date.now().toString(36), number, user_email: u ? u.email : null, customer: payload.customer, address: payload.address, notes: payload.notes,
        payment_method: payload.payment_method, installments: payload.installments, coupon_code: payload.coupon || null, discount: disc, subtotal, shipping_cost: ship, total: subtotal - disc + ship,
        status: 'aguardando_pagamento', created_at: new Date().toISOString(), order_items: items };
      ls.set('coxilha.orders', [order, ...orders]);
      return { id: order.id, number, subtotal, shipping_cost: ship, discount: disc, total: order.total, status: order.status };
    },
    async myOrders() {
      const u = await Store.auth.user(); if (!u) return [];
      if (mode === 'supabase') return sb('/rest/v1/orders?select=number,total,status,created_at,order_items(product_name,quantity)&order=created_at.desc');
      return ls.get('coxilha.orders', []).filter((o) => o.user_email === u.email);
    },

    /* ------------------------------------------------------------ Orçamento, contato e newsletter */
    async sendRequest(kind, d) {
      const row = { kind, name: d.name, email: d.email, phone: d.phone || null, dimensions: d.dimensions || null, message: d.message };
      if (mode === 'supabase') {
        if (d.productSlug) { const p = await Store.product(d.productSlug); if (p) row.product_id = p.id; }
        await sb('/rest/v1/quote_requests', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: row });
      } else {
        const l = ls.get('coxilha.requests', []); l.unshift({ ...row, product: d.productSlug || null, id: 'q_' + Date.now().toString(36), created_at: new Date().toISOString() }); ls.set('coxilha.requests', l);
      }
    },
    async subscribe(email) {
      email = email.trim().toLowerCase();
      if (mode === 'supabase') {
        try { await sb('/rest/v1/newsletter_subscribers', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: { email } }); }
        catch (e) { if (e.status !== 409 && e.code !== '23505') throw e; }
      } else { const l = ls.get('coxilha.newsletter', []); if (!l.includes(email)) ls.set('coxilha.newsletter', [...l, email]); }
    }
  };

  async function hash(s) {   // apenas modo local (demo); em produção quem guarda a senha é o Supabase Auth
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('coxilha:' + s));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
  }

  /* ------------------------------------------------------------ Carrinho (localStorage) */
  const MAX_QTY = 20;
  const Cart = {
    items: () => ls.get('coxilha.cart', []),
    _save(l) { ls.set('coxilha.cart', l); emit('cart:change'); },
    count: () => Cart.items().reduce((s, i) => s + i.qty, 0),
    add(slug, variantId, qty = 1) {
      const l = Cart.items(); const it = l.find((i) => i.variantId === variantId);
      if (it) it.qty = Math.min(MAX_QTY, it.qty + qty); else l.push({ slug, variantId, qty: Math.min(MAX_QTY, qty) });
      Cart._save(l);
    },
    setQty(variantId, qty) {
      qty = Math.max(1, Math.min(MAX_QTY, Math.floor(+qty) || 1));
      Cart._save(Cart.items().map((i) => (i.variantId === variantId ? { ...i, qty } : i)));
    },
    remove: (variantId) => Cart._save(Cart.items().filter((i) => i.variantId !== variantId)),
    clear: () => Cart._save([]),
    /* Resolve itens do carrinho com dados atuais do catálogo (preços vêm sempre do catálogo). */
    async lines() {
      const out = [];
      for (const it of Cart.items()) {
        const p = await Store.product(it.slug); const v = p && p.variants.find((x) => x.id === it.variantId);
        if (p && v) out.push({ product: p, variant: v, qty: it.qty, total: v.price * it.qty });
      }
      // remove do armazenamento itens que não existem mais no catálogo
      if (out.length !== Cart.items().length) ls.set('coxilha.cart', out.map((l) => ({ slug: l.product.slug, variantId: l.variant.id, qty: l.qty })));
      return out;
    },
    subtotal: (lines) => lines.reduce((s, l) => s + l.total, 0),
    MAX_QTY
  };

  window.Store = Store; window.Cart = Cart; window.LS = ls;
})();
