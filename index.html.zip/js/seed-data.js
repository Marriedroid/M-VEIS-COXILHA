/*
 * Dados iniciais do catálogo. Em modo Supabase, o banco é a fonte da verdade
 * (esses mesmos dados geram supabase/seed.sql via scripts/gen-seed.mjs).
 * Em modo local, este arquivo alimenta o catálogo.
 * Textos marcados com [revisar] foram escritos para completar as telas.
 */
window.COXILHA_SEED = {
  categories: [
    { slug: 'mesas', image: 'assets/img/cat-mesas.jpg', name: 'Mesas', short_name: 'Mesas', tagline: 'O centro dos encontros', sort_order: 1 },
    { slug: 'bancos-e-cadeiras', image: 'assets/img/cat-bancos.jpg', name: 'Bancos e cadeiras', short_name: 'Bancos e cadeiras', tagline: 'Um convite a ficar', sort_order: 2 },
    { slug: 'moveis-de-apoio', image: 'assets/img/cat-apoio.jpg', name: 'Móveis de apoio', short_name: 'Apoio', tagline: 'Espaço para o que importa', sort_order: 3 }
  ],
  products: [
    {
      slug: 'mesa-raiz', category: 'mesas', name: 'Mesa Raiz',
      subtitle: 'Mesa de jantar em madeira maciça · 6 lugares',
      kicker: 'Encontros que criam raízes',
      description: 'Desenho limpo, bordas suaves e a presença acolhedora do carvalho. Uma mesa para as conversas que merecem durar.',
      detail_title: 'Solidez que se sente.',
      detail_text: 'Tampo de 3 cm, cantos arredondados e base em painéis maciços. A construção valoriza a resistência, o toque e a beleza da matéria.',
      image: 'assets/img/mesa-raiz.jpg', home_image: 'assets/img/home-mesa-raiz.jpg',
      gallery: ['assets/img/mesa-raiz-1.jpg', 'assets/img/mesa-raiz-2.jpg', 'assets/img/mesa-raiz-3.jpg'],
      detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 180, featured: 1, installments: 10, lead_time_days: 25,
      specs: [
        ['Material', 'Carvalho maciço'], ['Acabamento', 'Óleo-cera fosco natural'],
        ['Dimensões', '180 × 90 × 76 cm'], ['Espessura do tampo', '3 cm'],
        ['Peso aproximado', '42 kg'], ['Capacidade', '6 lugares'],
        ['Montagem', 'Base enviada desmontada; manual incluso'],
        ['Produção', 'Até 25 dias úteis após o pagamento']
      ],
      variants: [{ wood: 'Carvalho natural', finish: 'Óleo-cera fosco · toque natural', dimensions: '180 × 90 × 76 cm', price: 3290 }]
    },
    {
      slug: 'banco-vereda', category: 'bancos-e-cadeiras', name: 'Banco Vereda',
      subtitle: 'Banco em madeira maciça · 2 a 3 lugares', kicker: 'Um caminho até a sua casa',
      description: 'Linhas retas e assento generoso. Um banco que serve à entrada, à mesa e ao pé da cama.', /* [revisar] */
      detail_title: 'Simples, firme, feito para ficar.', detail_text: 'Tampo maciço sobre pés em painel, com cantos suavizados e acabamento que valoriza o veio do carvalho.', /* [revisar] */
      image: 'assets/img/banco-vereda.jpg', home_image: 'assets/img/home-banco-vereda.jpg', gallery: ['assets/img/banco-vereda.jpg'], detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 120, featured: 1, installments: 10, lead_time_days: 25,
      specs: [['Material', 'Carvalho maciço'], ['Acabamento', 'Óleo-cera fosco natural'], ['Dimensões', '120 × 35 cm'], ['Produção', 'Até 25 dias úteis após o pagamento']],
      variants: [{ wood: 'Carvalho natural', finish: 'Óleo-cera fosco · toque natural', dimensions: '120 × 35 cm', price: 1190 }]
    },
    {
      slug: 'cadeira-trama', category: 'bancos-e-cadeiras', name: 'Cadeira Trama',
      subtitle: 'Cadeira em carvalho com assento de corda', kicker: 'Feita para sentar com calma',
      description: 'Estrutura leve em carvalho e assento em corda trançada à mão. Conforto discreto para a mesa de todo dia.', /* [revisar] */
      detail_title: 'Leve na forma, firme no uso.', detail_text: 'Encaixes precisos e assento trançado que acompanha o corpo com o passar do tempo.', /* [revisar] */
      image: 'assets/img/cadeira-trama.jpg', home_image: 'assets/img/home-cadeira-trama.jpg', gallery: ['assets/img/cadeira-trama.jpg'], detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 52, featured: 1, installments: 10, lead_time_days: 25,
      specs: [['Material', 'Carvalho e corda'], ['Acabamento', 'Óleo-cera fosco natural'], ['Dimensões', '48 × 52 cm'], ['Produção', 'Até 25 dias úteis após o pagamento']],
      variants: [{ wood: 'Carvalho e corda', finish: 'Óleo-cera fosco · toque natural', dimensions: '48 × 52 cm', price: 890 }]
    },
    {
      slug: 'mesa-lateral-elo', category: 'mesas', name: 'Mesa lateral Elo',
      subtitle: 'Mesa lateral redonda em madeira maciça', kicker: 'O elo entre um lugar e outro',
      description: 'Base em coluna e tampo redondo. Apoio para o café, o livro e o vaso ao lado do sofá.', /* [revisar] */
      detail_title: 'Pequena, mas com presença.', detail_text: 'Peça única em carvalho, com veios que variam naturalmente de uma mesa para outra.', /* [revisar] */
      image: 'assets/img/mesa-lateral-elo.jpg', gallery: ['assets/img/mesa-lateral-elo.jpg'], detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 45, featured: 0, installments: 10, lead_time_days: 25,
      specs: [['Material', 'Carvalho maciço'], ['Acabamento', 'Óleo-cera fosco natural'], ['Dimensões', 'Ø 45 cm'], ['Produção', 'Até 25 dias úteis após o pagamento']],
      variants: [{ wood: 'Carvalho natural', finish: 'Óleo-cera fosco · toque natural', dimensions: 'Ø 45 cm', price: 690 }]
    },
    {
      slug: 'buffet-horizonte', category: 'moveis-de-apoio', name: 'Buffet Horizonte',
      subtitle: 'Buffet em madeira maciça com portas e gavetas', kicker: 'Espaço para o que importa',
      description: 'Frentes em veio contínuo e puxadores embutidos. Guarda o essencial e recebe o que você ama expor.', /* [revisar] */
      detail_title: 'Veios que seguem de ponta a ponta.', detail_text: 'Frentes selecionadas para que o desenho da madeira continue entre portas e gavetas.', /* [revisar] */
      image: 'assets/img/buffet-horizonte.jpg', gallery: ['assets/img/buffet-horizonte.jpg'], detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 160, featured: 0, installments: 10, lead_time_days: 25,
      specs: [['Material', 'Carvalho maciço'], ['Acabamento', 'Óleo-cera fosco natural'], ['Dimensões', '160 × 45 cm'], ['Produção', 'Até 25 dias úteis após o pagamento']],
      variants: [{ wood: 'Carvalho natural', finish: 'Óleo-cera fosco · toque natural', dimensions: '160 × 45 cm', price: 3890 }]
    },
    {
      slug: 'mesa-de-centro-seixo', category: 'mesas', name: 'Mesa de centro Seixo',
      subtitle: 'Mesa de centro orgânica em madeira maciça', kicker: 'Uma pausa no meio do dia',
      description: 'Tampo de formas suaves sobre pés roliços. Luz, textura e o calor que transforma o espaço em abrigo.', /* [revisar] */
      detail_title: 'Formas que lembram pedra de rio.', detail_text: 'Cantos arredondados, pés torneados e acabamento fosco que convida ao toque.', /* [revisar] */
      image: 'assets/img/mesa-centro-seixo.jpg', gallery: ['assets/img/mesa-centro-seixo.jpg', 'assets/img/sala.jpg'], detail_image: 'assets/img/detalhe-carvalho.jpg',
      max_dimension_cm: 110, featured: 1, installments: 10, lead_time_days: 25,
      specs: [['Material', 'Carvalho maciço'], ['Acabamento', 'Óleo-cera fosco natural'], ['Dimensões', '110 × 60 cm'], ['Produção', 'Até 25 dias úteis após o pagamento']],
      variants: [{ wood: 'Carvalho natural', finish: 'Óleo-cera fosco · toque natural', dimensions: '110 × 60 cm', price: 1490 }]
    }
  ],
  faq: [
    ['Os móveis são feitos sob encomenda?', 'Sim. A produção começa após a confirmação do pagamento e leva até 25 dias úteis. O transporte é somado a esse prazo e calculado pelo seu CEP.'],
    ['Como funciona a entrega?', 'Entrega agendada, em até 7 dias úteis após a fabricação. Entramos em contato para combinar o melhor dia e orientar o recebimento.'],
    ['A madeira pode variar de cor?', 'Pode. Cada peça tem veios e tons próprios, e é isso que a torna única. As imagens são ilustrativas.'],
    ['Como cuidar da minha peça?', 'Limpe com pano macio levemente úmido e seque em seguida. Evite sol direto, abrasivos e calor sobre o tampo.']
  ],
  shipping_rates: [
    { uf: 'SP', price: 180, days_min: 1, days_max: 7 },
    { uf: 'DEFAULT', price: 280, days_min: 1, days_max: 12 } // placeholder: ajustar
  ]
};
