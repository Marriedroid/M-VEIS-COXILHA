(async function () {
  Layout.init({ page: 'catalog' });
  const { I, productCard } = Layout; const { esc } = U;
  const $ = (id) => document.getElementById(id);

  const PRICE_LABELS = { ate1000: 'Até R$ 1.000', de1000a2000: 'R$ 1.000 a R$ 2.000', acima2000: 'Acima de R$ 2.000' };
  const WIDTH_LABELS = { ate100: 'Até 100 cm', de101a150: 'De 101 a 150 cm', acima150: 'Acima de 150 cm' };
  const csv = (k) => (new URLSearchParams(location.search).get(k) || '').split(',').filter(Boolean);

  const state = { q: U.qs('q') || '', category: csv('categoria'), price: csv('preco'), width: csv('largura'), wood: csv('madeira'), avail: csv('disp'), sort: U.qs('ordem') || 'destaques' };

  let cats = [], all = [];
  try { [cats, all] = await Promise.all([Store.categories(), Store.allProducts()]); }
  catch (e) { $('results').innerHTML = `<div class="empty-state"><h3>Não foi possível carregar os móveis.</h3><p>${esc(e.message)}</p><button class="btn btn-outline" onclick="location.reload()">Tentar novamente</button></div>`; return; }

  /* ----- contagens (sobre o catálogo inteiro, como no design) ----- */
  const woods = [...new Set(all.flatMap((p) => p.variants.map((v) => v.wood)))];
  const catCount = (slug) => all.filter((p) => p.category && p.category.slug === slug).length;
  const inRange = (map, key, v) => v >= map[key][0] && v <= map[key][1];

  function group(id, title, opts) {
    return `<div class="fgroup" data-expanded="true" data-g="${id}"><button type="button" aria-expanded="true">${title}<span class="v">${I('minus', 'ico-sm')}</span><span class="h">${I('plus', 'ico-sm')}</span></button>
      <div class="fopts">${opts.map((o) => `<label class="fopt"><input type="checkbox" data-f="${id}" value="${esc(o.value)}"> ${esc(o.label)}</label>`).join('')}</div></div>`;
  }
  $('fbody').innerHTML =
    group('category', 'Categoria', cats.map((c) => ({ value: c.slug, label: `${c.name} (${catCount(c.slug)})` }))) +
    group('price', 'Faixa de preço', Object.entries(PRICE_LABELS).map(([value, label]) => ({ value, label }))) +
    group('wood', 'Madeira', woods.map((w) => ({ value: w, label: `${w} (${all.filter((p) => p.variants.some((v) => v.wood === w)).length})` }))) +
    group('width', 'Largura', Object.entries(WIDTH_LABELS).map(([value, label]) => ({ value, label }))) +
    group('avail', 'Disponibilidade', [{ value: 'sob_encomenda', label: `Sob encomenda (${all.length})` }]) +
    `<p class="fhelp">Precisa de outra medida? Vamos conversar sobre a sua peça.</p>
     <button type="button" class="link" data-open="quote">Falar com a oficina ${I('arrow', 'ico-sm')}</button>`;

  $('chips').innerHTML = `<button type="button" class="chip" data-cat="">Todos os móveis</button>` + cats.map((c) => `<button type="button" class="chip" data-cat="${esc(c.slug)}">${esc(c.short_name || c.name)}</button>`).join('');

  /* ----- aplicar estado ----- */
  const filtersObj = () => ({ q: state.q, category: state.category, price: state.price, width: state.width, wood: state.wood, sort: state.sort });
  const hasFilters = () => state.q || state.category.length || state.price.length || state.width.length || state.wood.length || state.avail.length;

  function syncControls() {
    $('q').value = state.q; $('sort').value = state.sort;
    document.querySelectorAll('[data-f]').forEach((i) => { i.checked = (state[i.dataset.f] || []).includes(i.value); });
    document.querySelectorAll('.chip').forEach((c) => {
      const on = c.dataset.cat === '' ? !state.category.length : (state.category.length === 1 && state.category[0] === c.dataset.cat);
      c.classList.toggle('on', on); c.setAttribute('aria-pressed', on);
    });
  }
  function syncUrl() {
    const p = new URLSearchParams();
    if (state.q) p.set('q', state.q);
    [['categoria', 'category'], ['preco', 'price'], ['largura', 'width'], ['madeira', 'wood'], ['disp', 'avail']].forEach(([k, s]) => state[s].length && p.set(k, state[s].join(',')));
    if (state.sort !== 'destaques') p.set('ordem', state.sort);
    history.replaceState(null, '', location.pathname + (p.toString() ? '?' + p : ''));
  }
  async function render() {
    syncControls(); syncUrl();
    let list = await Store.products(filtersObj());
    if (state.avail.length && !state.avail.includes('sob_encomenda')) list = [];   // todas as peças são sob encomenda
    const n = list.length;
    $('count').textContent = `${n} ${n === 1 ? 'peça encontrada' : 'peças encontradas'}`;
    $('results').innerHTML = n ? list.map((p) => productCard(p)).join('') :
      `<div class="empty-state"><h3>Nenhuma peça encontrada.</h3><p>Tente outros termos ou limpe os filtros. Se procura algo específico, a oficina pode desenhar com você.</p>
       <button type="button" class="btn btn-outline" id="empty-clear" style="margin-right:10px">Limpar filtros</button><button type="button" class="btn" data-open="quote">Falar com a oficina</button></div>`;
    $('end').textContent = n ? (hasFilters() ? `Você viu ${n === 1 ? 'a peça encontrada' : `as ${n} peças encontradas`}.` : `Você viu as ${n} peças da coleção Origem.`) : '';
    $('end').hidden = !n;
    const ec = $('empty-clear'); if (ec) ec.addEventListener('click', clearAll);
    Layout.syncFavs($('results'));
  }
  function clearAll() { Object.assign(state, { q: '', category: [], price: [], width: [], wood: [], avail: [], sort: 'destaques' }); render(); }

  /* ----- eventos ----- */
  $('fbody').addEventListener('change', (e) => {
    const i = e.target.closest('[data-f]'); if (!i) return; const arr = state[i.dataset.f];
    state[i.dataset.f] = i.checked ? [...arr, i.value] : arr.filter((v) => v !== i.value); render();
  });
  $('fbody').addEventListener('click', (e) => {
    const b = e.target.closest('.fgroup > button'); if (!b) return; const g = b.parentElement; const open = g.dataset.expanded !== "true";
    g.dataset.expanded = open; b.setAttribute('aria-expanded', open);
  });
  $('chips').addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (!c) return; state.category = c.dataset.cat ? [c.dataset.cat] : []; render(); });
  $('sort').addEventListener('change', (e) => { state.sort = e.target.value; render(); });
  $('clear').addEventListener('click', clearAll);
  $('q').addEventListener('input', U.debounce((e) => { state.q = e.target.value.trim(); render(); }, 200));
  $('search-form').addEventListener('submit', (e) => { e.preventDefault(); state.q = $('q').value.trim(); render(); });
  $('filters-toggle').addEventListener('click', () => { const f = $('filters'); const o = !f.classList.contains('open'); f.classList.toggle('open', o); $('filters-toggle').setAttribute('aria-expanded', o); });

  render();
})();
