(async function () {
  Layout.init({ page: 'home' });
  const { I, productCard } = Layout; const { esc, money } = U;
  const SCENE_SLUG = 'mesa-de-centro-seixo';

  document.getElementById('strip').innerHTML =
    `<span>${I('hand')} Feito à mão, peça a peça</span><span>${I('leaf')} Madeira natural, sem imitações</span><span>${I('truck')} Entrega cuidada e agendada</span>`;

  const faq = [
    ['Os móveis são feitos sob encomenda?', 'Sim. A produção começa após a confirmação do pagamento e leva até 25 dias úteis. O transporte é somado a esse prazo e calculado pelo seu CEP.'],
    ['Como funciona a entrega?', 'Entrega agendada, em até 7 dias úteis após a fabricação. Quando o pedido tem mais de uma peça, enviamos tudo junto. Entramos em contato para combinar o melhor dia.'],
    ['A madeira pode variar de cor?', 'Pode. Cada peça tem veios, nós e tons próprios, e é isso que a torna única. As imagens são ilustrativas.'],
    ['Como cuidar da minha peça?', 'Limpe com pano macio levemente úmido e seque em seguida. Evite sol direto, abrasivos e calor sobre o tampo. Use apoio para copos e panelas.']
  ];
  const acc = document.getElementById('faq');
  acc.innerHTML = faq.map(([q, a], i) => `<div class="acc-item${i === 0 ? ' open' : ''}"><button type="button" class="acc-q" aria-expanded="${i === 0}">${esc(q)}${I('plus', 'plus')}${I('minus', 'minus')}</button><div class="acc-a">${esc(a)}</div></div>`).join('');
  Layout.accordion(acc);

  try {
    const [cats, all] = await Promise.all([Store.categories(), Store.allProducts()]);
    document.getElementById('cats').innerHTML = cats.map((c, i) =>
      `<a class="cat${i === 1 ? ' tall' : ''}" href="catalogo.html?categoria=${esc(c.slug)}"><img src="${esc(c.image)}" alt="${esc(c.name)}" loading="lazy">
        <div class="cat-info"><div><h3>${esc(c.name)}</h3><p>${esc(c.tagline || '')}</p></div>${I('arrow')}</div></a>`).join('');

    const feat = (await Store.products({ sort: 'destaques' })).slice(0, 3);
    document.getElementById('featured').innerHTML = feat.map((p) => productCard(p, { home: true })).join('');
    Layout.syncFavs(document.getElementById('featured'));

    if (feat[0]) { const hc = document.getElementById('hero-card'); hc.href = 'produto.html?slug=' + feat[0].slug; hc.querySelector('b').textContent = feat[0].name; hc.querySelector('span').textContent = `${feat[0].variants[0].wood} · ${money(Store.minPrice(feat[0]))}`; }
    const scene = all.find((p) => p.slug === SCENE_SLUG);
    if (scene) { document.getElementById('scene').textContent = `Na cena: ${scene.name} · ${scene.variants[0].wood} · ${money(Store.minPrice(scene))}`; document.getElementById('scene-btn').href = 'produto.html?slug=' + scene.slug; }
  } catch (e) { Layout.toast('Não foi possível carregar os produtos. ' + e.message, { type: 'err' }); }

  // Newsletter
  const nf = document.getElementById('news-form');
  Layout.submit(nf, { email: [U.r.required('Informe seu e-mail.'), U.r.email()] }, async (v) => {
    await Store.subscribe(v.email); nf.reset(); Layout.toast('Pronto! Você vai receber nossas novidades com calma.');
  });
  if (location.hash) setTimeout(() => document.querySelector(location.hash)?.scrollIntoView(), 50);
})();
