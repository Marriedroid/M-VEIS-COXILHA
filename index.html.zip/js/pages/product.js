(async function () {
  Layout.init({ page: 'product' });
  const { I, productCard } = Layout; const { esc, money } = U;
  const root = document.getElementById('product-root');
  const slug = U.qs('slug');

  let p = null;
  try { p = slug ? await Store.product(slug) : null; }
  catch (e) { root.innerHTML = `<div class="wrap empty-cart"><h2>Não foi possível carregar a peça.</h2><p>${esc(e.message)}</p><button class="btn" onclick="location.reload()">Tentar novamente</button></div>`; return; }
  if (!p) { root.innerHTML = `<div class="wrap empty-cart"><h2>Não encontramos esta peça.</h2><p>Ela pode ter saído da coleção ou o endereço está incorreto.</p><a class="btn" href="catalogo.html">Ver todos os móveis ${I('arrow', 'ico-sm')}</a></div>`; return; }

  document.title = `${p.name} — Móveis Coxilha`;
  document.querySelector('meta[name=description]').content = p.description || p.subtitle || '';
  const art = /^(Mesa|Cadeira)/.test(p.name) ? 'a' : 'o';

  const combos = []; p.variants.forEach((v) => { if (!combos.some((c) => c.wood === v.wood && c.finish === v.finish)) combos.push({ wood: v.wood, finish: v.finish }); });
  const sel = { combo: 0, variantId: p.variants[0].id, qty: 1, img: 0 };
  const gallery = p.gallery.length ? p.gallery : [p.image];
  const curVariant = () => p.variants.find((v) => v.id === sel.variantId);

  root.innerHTML = `
  <div class="wrap"><nav class="crumbs" aria-label="Você está em"><a href="index.html">Início</a><span>/</span><a href="catalogo.html">Móveis</a><span>/</span><span style="margin:0">${esc(p.name)}</span></nav>
    <div class="pdp">
      <figure class="gallery" style="margin:0"><div class="main"><img id="g-main" src="${esc(gallery[0])}" alt="${esc(p.name)}"><span class="badge">Coleção Origem</span>
        <button type="button" class="expand" id="g-zoom" aria-label="Ampliar imagem">${I('expand', 'ico-sm')}</button></div>
        ${gallery.length > 1 ? `<div class="thumbs" id="g-thumbs">${gallery.map((g, i) => `<button type="button" data-i="${i}" aria-label="Ver imagem ${i + 1}" aria-current="${i === 0}"><img src="${esc(g)}" alt=""></button>`).join('')}</div>` : ''}
        <figcaption>Imagens ilustrativas. Os veios e tons variam naturalmente em cada peça.</figcaption></figure>
      <div class="pinfo"><span class="kicker">${esc(p.kicker || '')}</span>
        <div class="pinfo-title"><h1>${esc(p.name)}</h1><button type="button" class="fav" data-fav="${esc(p.id)}" aria-pressed="false" aria-label="Favoritar ${esc(p.name)}">${I('heart')}</button></div>
        <p class="sub">${esc(p.subtitle || '')}</p>
        <p class="pprice" id="price"></p><p class="pinst" id="inst"></p><hr>
        <p class="pdesc">${esc(p.description || '')}</p>
        <span class="opt-label" id="lbl-wood">Madeira e acabamento</span><div role="radiogroup" aria-labelledby="lbl-wood" id="combos"></div>
        <label class="opt-label" for="size">Medida · comprimento × profundidade × altura</label>
        <div class="select"><select id="size"></select>${I('chev')}</div>
        <p class="lead-note">${I('hammer')} Feita para você em até ${p.lead_time_days} dias úteis.</p>
        <div class="buy"><div class="stepper" aria-label="Quantidade"><button type="button" id="dec" aria-label="Diminuir quantidade">${I('minus', 'ico-sm')}</button><input id="qty" type="number" min="1" max="${Cart.MAX_QTY}" value="1" inputmode="numeric" aria-label="Quantidade"><button type="button" id="inc" aria-label="Aumentar quantidade">${I('plus', 'ico-sm')}</button></div>
          <button type="button" class="btn" id="add">Adicionar ao carrinho ${I('arrow', 'ico-sm')}</button></div>
        <p class="measure">${I('tag', 'ico-sm')}<span>Precisa de outra medida?</span><button type="button" data-open="quote" data-product="${esc(p.slug)}">Fale com a oficina ${I('arrow', 'ico-sm')}</button></p>
        <hr style="margin-top:28px"><span class="opt-label" style="margin-top:0">Entrega para a sua casa</span>
        <form class="cepbox" id="cep-form" novalidate><label class="sr-only" for="cep">CEP</label><input id="cep" inputmode="numeric" data-mask="cep" placeholder="00000-000" autocomplete="postal-code"><button type="submit">Calcular</button></form>
        <p class="ship-result" id="ship-result" aria-live="polite"></p>
      </div></div></div>

  <section class="details"><div class="wrap details-in">
    <div><span class="kicker">O essencial, em cada detalhe</span><h2>${esc(p.detail_title || '')}</h2><p class="muted">${esc(p.detail_text || '')}</p>${p.detail_image ? `<img src="${esc(p.detail_image)}" alt="Detalhe de ${esc(p.name)}" loading="lazy">` : ''}</div>
    <div><h3>Conheça a sua peça.</h3><dl class="specs">${(p.specs || []).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl></div>
  </div></section>

  <div class="wrap"><div class="triple">
    <div><h3>Cuidado que prolonga</h3><p>Limpe com pano macio levemente úmido e seque em seguida. Evite sol direto, abrasivos e calor sobre o tampo. Use apoio para copos e panelas.</p></div>
    <div><h3>Entrega sem pressa, sem surpresa</h3><p>O prazo total é de até ${p.lead_time_days} dias úteis de fabricação + 7 dias úteis de transporte para o CEP informado. Confira acessos, portas e elevadores antes da compra.</p></div>
    <div><h3>Uma compra bem informada</h3><p>Você tem 7 dias após o recebimento para solicitar o arrependimento nas compras online. Consulte a <button type="button" data-info="trocas" style="text-decoration:underline">política completa</button> de trocas, devoluções e avarias.</p></div></div>
    <section class="compose"><span class="kicker">Componha com naturalidade</span><h2>Boas companhias para ${art} ${esc(p.name)}.</h2><div class="grid3" id="related"></div></section></div>`;

  const $ = (id) => document.getElementById(id);

  /* ----- variações ----- */
  function renderOptions() {
    const c = combos[sel.combo];
    $('combos').innerHTML = combos.map((x, i) => `<button type="button" role="radio" class="opt-card" aria-checked="${i === sel.combo}" data-i="${i}"><img src="${esc(p.detail_image || p.image)}" alt=""><span><b>${esc(x.wood)}</b><small>${esc(x.finish)}</small></span><span class="ck">${I('checkc')}</span></button>`).join('');
    const vs = p.variants.filter((v) => v.wood === c.wood && v.finish === c.finish);
    if (!vs.some((v) => v.id === sel.variantId)) sel.variantId = vs[0].id;
    $('size').innerHTML = vs.map((v) => `<option value="${esc(v.id)}"${v.id === sel.variantId ? ' selected' : ''}>${esc(v.dimensions)}${vs.length > 1 ? ' — ' + money(v.price) : ''}</option>`).join('');
    renderPrice();
  }
  function renderPrice() {
    const v = curVariant(); const n = p.installments;
    $('price').textContent = money(v.price); $('inst').textContent = `ou ${n}x de ${money(v.price / n)} sem juros`;
  }
  $('combos').addEventListener('click', (e) => { const b = e.target.closest('[data-i]'); if (b) { sel.combo = +b.dataset.i; renderOptions(); } });
  $('size').addEventListener('change', (e) => { sel.variantId = e.target.value; renderPrice(); });
  renderOptions();

  /* ----- galeria ----- */
  const setImg = (i) => { sel.img = i; $('g-main').src = gallery[i]; document.querySelectorAll('#g-thumbs button').forEach((b) => b.setAttribute('aria-current', +b.dataset.i === i)); };
  const th = $('g-thumbs'); if (th) th.addEventListener('click', (e) => { const b = e.target.closest('[data-i]'); if (b) setImg(+b.dataset.i); });
  $('g-zoom').addEventListener('click', () => Layout.lightbox(gallery[sel.img], p.name));

  /* ----- quantidade e carrinho ----- */
  const q = $('qty'); const clamp = () => { sel.qty = Math.max(1, Math.min(Cart.MAX_QTY, Math.floor(+q.value) || 1)); q.value = sel.qty; };
  $('dec').addEventListener('click', () => { q.value = +q.value - 1; clamp(); });
  $('inc').addEventListener('click', () => { q.value = +q.value + 1; clamp(); });
  q.addEventListener('change', clamp);
  $('add').addEventListener('click', () => {
    clamp(); Cart.add(p.slug, sel.variantId, sel.qty);
    Layout.toast(`${p.name} adicionada ao carrinho.`, { action: { href: 'carrinho.html', label: 'Ver carrinho' } });
  });

  /* ----- frete ----- */
  const saved = Store.savedCep(); const cepIn = $('cep'); const res = $('ship-result');
  if (saved) { cepIn.value = U.maskCEP(saved.cep); showQuote(saved); }
  function showQuote(r) { res.className = 'ship-result'; res.textContent = `${r.city ? r.city + (r.uf ? ', ' + r.uf : '') + ' · ' : ''}${money(r.price)}. Entrega agendada em até ${r.transpDays} dias úteis após a fabricação.`; }
  $('cep-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!U.isCEP(cepIn.value)) { res.className = 'ship-result err'; res.textContent = 'Informe um CEP válido com 8 números.'; cepIn.focus(); return; }
    res.className = 'ship-result'; res.textContent = 'Calculando…';
    try { const r = await Store.shippingQuote(cepIn.value); Store.saveCep(r); showQuote(r); }
    catch (err) { res.className = 'ship-result err'; res.textContent = err.message; }
  });

  /* ----- relacionados e favoritos ----- */
  const rel = await Store.related(p, 3);
  $('related').innerHTML = rel.map((r) => productCard(r)).join('');
  Layout.syncFavs(root);
})();
