(async function () {
  Layout.init({ page: 'cart' });
  const { I } = Layout; const { esc, money } = U;
  const root = document.getElementById('cart-root');
  let quote = Store.savedCep(); let coupon = null; let couponMsg = '';

  document.getElementById('promises').innerHTML = [
    ['hammer', 'Feito para você', 'Cada peça entra em produção após a confirmação do pagamento.'],
    ['truck', 'Entrega com cuidado', 'Agendamento e orientações para receber seu móvel com tranquilidade.'],
    ['handheart', 'Conversa de verdade', 'Acompanhamento do pedido, da nossa oficina até a sua casa.']
  ].map(([i, t, p]) => `<div class="promise">${I(i, '')}<div><b>${t}</b><p>${p}</p></div></div>`).join('');

  async function refreshCoupon(subtotal) {
    const saved = Store.savedCoupon(); coupon = null;
    if (!saved) return;
    try { coupon = await Store.coupon(saved.code, subtotal); Store.saveCoupon(coupon); }
    catch (e) { Store.saveCoupon(null); couponMsg = e.message; }
  }

  async function render(keepFocus) {
    let lines;
    try { lines = await Cart.lines(); } catch (e) { root.innerHTML = `<div class="empty-cart"><h2>Não foi possível carregar o carrinho.</h2><p>${esc(e.message)}</p><button class="btn" onclick="location.reload()">Tentar novamente</button></div>`; return; }
    const count = lines.reduce((s, l) => s + l.qty, 0);
    document.getElementById('subtitle').textContent = count ? `Seu carrinho tem ${count} ${count === 1 ? 'peça feita' : 'peças feitas'} para ficar.` : 'Seu carrinho está vazio por enquanto.';
    if (!lines.length) {
      root.innerHTML = `<div class="empty-cart"><h2>Nada por aqui ainda.</h2><p>Quando você escolher uma peça, ela espera aqui, com calma.</p><a class="btn" href="catalogo.html">Ver todos os móveis ${I('arrow', 'ico-sm')}</a></div>`; return;
    }
    await refreshCoupon(Cart.subtotal(lines));
    const t = Store.totals(lines, quote, coupon);
    const prevCep = document.getElementById('cep') ? document.getElementById('cep').value : null;

    root.innerHTML = `<div class="cart-grid"><div>
      <div class="thead"><span>Produto</span><span class="q">Quantidade</span><span>Valor</span></div>
      ${lines.map((l) => `<div class="item" data-id="${esc(l.variant.id)}"><a href="produto.html?slug=${esc(l.product.slug)}"><img src="${esc(l.product.image)}" alt="${esc(l.product.name)}"></a>
        <div><h3><a href="produto.html?slug=${esc(l.product.slug)}">${esc(l.product.name)}</a></h3>
          <p class="meta">${esc(l.variant.wood)} · ${esc(l.variant.dimensions)}</p><p class="meta">${esc(l.variant.finish.split(' · ')[0])} · produção: ${l.product.lead_time_days} dias úteis</p>
          <div class="qrow"><div class="stepper sm"><button type="button" data-act="dec" aria-label="Diminuir quantidade de ${esc(l.product.name)}">${I('minus', 'ico-sm')}</button><input type="number" min="1" max="${Cart.MAX_QTY}" value="${l.qty}" data-act="qty" aria-label="Quantidade de ${esc(l.product.name)}"><button type="button" data-act="inc" aria-label="Aumentar quantidade de ${esc(l.product.name)}">${I('plus', 'ico-sm')}</button></div></div>
          <button type="button" class="remove" data-act="rm">Remover peça</button></div>
        <div class="iprice">${money(l.total)}${l.qty > 1 ? `<span class="unit">${money(l.variant.price)} cada</span>` : ''}</div></div>`).join('')}
      <section class="ship"><h2>Como suas peças chegam.</h2><form id="cep-form" novalidate><label class="lbl" for="cep">Calcule pelo seu CEP</label>
        <div class="ship-row"><input id="cep" inputmode="numeric" data-mask="cep" placeholder="00000-000" autocomplete="postal-code" value="${quote ? U.maskCEP(quote.cep) : ''}"><button class="btn btn-outline" type="submit">Calcular ${I('arrow', 'ico-sm')}</button></div>
        <p class="field-error" id="cep-err" hidden></p></form>
        ${quote ? `<div class="ship-ok">${I('checkc')}<div><b>Entrega agendada · ${money(quote.price)}</b><p>${esc(quote.city ? quote.city + (quote.uf ? ', ' + quote.uf : '') + ' · ' : '')}Até ${quote.transpDays} dias úteis após a fabricação. ${count > 1 ? `Seu pedido é enviado junto, quando as ${count} peças estiverem prontas.` : 'Entramos em contato para agendar o recebimento.'}</p></div></div>` : ''}
        <div class="coupon"><button type="button" id="coupon-toggle" aria-expanded="${!!coupon}">${I('ticket')}<span>${coupon ? `Cupom ${esc(coupon.code)} aplicado` : 'Tem um cupom? Insira aqui'}</span>${I('plus', 'plus ico-sm')}</button>
          <div id="coupon-box" ${coupon || couponMsg ? '' : 'hidden'}>
            ${coupon ? `<p class="coupon-msg" style="color:var(--ok)">Desconto de ${money(coupon.discount)} aplicado. <button type="button" id="coupon-remove" style="text-decoration:underline">Remover cupom</button></p>`
      : `<form class="coupon-form" id="coupon-form" novalidate><label class="sr-only" for="coupon">Código do cupom</label><input id="coupon" placeholder="Código do cupom" autocomplete="off"><button type="submit" class="btn">Aplicar</button></form><p class="coupon-msg" id="coupon-msg" style="color:var(--danger)" role="alert">${esc(couponMsg)}</p>`}</div></div></section></div>

      <div><aside class="summary" aria-label="Resumo do pedido"><h2>Seu pedido, com cuidado.</h2>
        <div class="srow"><span>Subtotal · ${count} ${count === 1 ? 'peça' : 'peças'}</span><span>${money(t.subtotal)}</span></div>
        ${t.discount ? `<div class="srow disc"><span>Desconto (${esc(coupon.code)})</span><span>− ${money(t.discount)}</span></div>` : ''}
        <div class="srow"><span>Entrega agendada</span><span>${quote ? money(quote.price) : 'Calcule pelo CEP'}</span></div>
        ${quote ? `<div class="srow dim"><span>Para ${esc(quote.city || 'o seu CEP')}${quote.uf ? ', ' + esc(quote.uf) : ''} · CEP ${U.maskCEP(quote.cep)}</span></div>` : ''}
        <div class="stotal"><b>Total</b><strong>${money(t.total)}</strong></div>
        <p class="inst">${t.installments}x de ${money(t.installment)} sem juros</p>
        <button type="button" class="btn" id="go">Continuar para o checkout ${I('arrow', 'ico-sm')}</button>
        <p class="fine">Frete calculado. Nenhuma taxa surpresa.</p><p class="safe">${I('lock', 'ico-sm')} Seus dados e seu pagamento protegidos.</p></aside>
        <div class="side-help"><b>Alguma dúvida antes de seguir?</b><p>Nossa oficina ajuda com medidas, acabamentos e condições de entrega.</p><button type="button" class="link" data-open="contact">Conversar com a Coxilha ${I('arrow', 'ico-sm')}</button></div></div></div>`;
    U.bindMasks(root);
    if (keepFocus) { const el = root.querySelector(keepFocus); if (el) { el.focus(); if (el.select) el.select(); } }
    wire(lines);
  }

  function wire(lines) {
    root.querySelectorAll('.item').forEach((row) => {
      const id = row.dataset.id; const cur = () => Cart.items().find((i) => i.variantId === id).qty;
      row.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act;
        if (act === 'inc') Cart.setQty(id, cur() + 1);
        else if (act === 'dec') Cart.setQty(id, cur() - 1);
        else if (act === 'rm') { const name = row.querySelector('h3').textContent; Cart.remove(id); Layout.toast(`${name} removida do carrinho.`); }
        await render(act === 'rm' ? null : `.item[data-id="${id}"] [data-act=${act}]`);
      });
      row.querySelector('[data-act=qty]').addEventListener('change', async (e) => { Cart.setQty(id, e.target.value); await render(`.item[data-id="${id}"] [data-act=qty]`); });
    });

    const cep = root.querySelector('#cep'), err = root.querySelector('#cep-err');
    root.querySelector('#cep-form').addEventListener('submit', async (e) => {
      e.preventDefault(); err.hidden = true; cep.removeAttribute('aria-invalid');
      if (!U.isCEP(cep.value)) { err.textContent = 'Informe um CEP válido com 8 números.'; err.hidden = false; cep.setAttribute('aria-invalid', 'true'); return; }
      const btn = e.target.querySelector('button'); btn.disabled = true;
      try { quote = await Store.shippingQuote(cep.value); Store.saveCep(quote); await render(); Layout.toast('Frete calculado.'); }
      catch (ex) { err.textContent = ex.message; err.hidden = false; cep.setAttribute('aria-invalid', 'true'); btn.disabled = false; }
    });

    root.querySelector('#coupon-toggle').addEventListener('click', () => { const b = root.querySelector('#coupon-box'); b.hidden = !b.hidden; root.querySelector('#coupon-toggle').setAttribute('aria-expanded', !b.hidden); const i = root.querySelector('#coupon'); if (!b.hidden && i) i.focus(); });
    const cf = root.querySelector('#coupon-form');
    if (cf) cf.addEventListener('submit', async (e) => {
      e.preventDefault(); const code = root.querySelector('#coupon').value; couponMsg = '';
      try { const c = await Store.coupon(code, Cart.subtotal(lines)); Store.saveCoupon(c); Layout.toast('Cupom aplicado.'); await render(); }
      catch (ex) { couponMsg = ex.message; root.querySelector('#coupon-msg').textContent = couponMsg; }
    });
    const cr = root.querySelector('#coupon-remove'); if (cr) cr.addEventListener('click', async () => { Store.saveCoupon(null); couponMsg = ''; await render(); });

    root.querySelector('#go').addEventListener('click', () => {
      if (!quote) { Layout.toast('Calcule o frete pelo seu CEP para continuar.', { type: 'err' }); cep.focus(); cep.scrollIntoView({ block: 'center' }); return; }
      location.href = 'checkout.html';
    });
  }

  couponMsg = ''; render();
  window.addEventListener('storage', () => render());
})();
