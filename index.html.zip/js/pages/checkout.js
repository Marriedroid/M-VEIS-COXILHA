(async function () {
  Layout.init({ page: 'checkout', variant: 'checkout' });
  const { I } = Layout; const { esc, money } = U; const B = window.COXILHA_CONFIG.brand;
  const $ = (id) => document.getElementById(id);
  const form = $('co-form');
  const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
  const maxInst = window.COXILHA_CONFIG.payment.maxInstallments;

  $('help-hours').textContent = `Fale com a oficina · ${B.hours.replace('Seg. a sex., das 9h às 18h', 'Seg. a sex., 9h às 18h')}`;
  const hm = $('help-mail'); hm.href = 'mailto:' + B.email; hm.innerHTML = `${esc(B.email)} ${I('arrow', 'ico-sm')}`;

  let lines = await Cart.lines().catch(() => []);
  if (!lines.length) {
    $('co-root').innerHTML = `<div class="empty-cart"><h2>Seu carrinho está vazio.</h2><p>Escolha uma peça para finalizar a compra.</p><a class="btn" href="catalogo.html">Ver todos os móveis ${I('arrow', 'ico-sm')}</a></div>`; return;
  }
  let quote = Store.savedCep(); let coupon = null; let method = 'cartao'; let user = null;
  const count = lines.reduce((s, l) => s + l.qty, 0);
  if (Store.savedCoupon()) { try { coupon = await Store.coupon(Store.savedCoupon().code, Cart.subtotal(lines)); } catch { Store.saveCoupon(null); } }

  /* ----- resumo, entrega e parcelas ----- */
  function renderSummary() {
    const t = Store.totals(lines, quote, coupon); const n = Math.max(1, +$('installments').value || t.installments);
    $('sum-list').innerHTML = lines.map((l) => `<div class="sum-item"><img src="${esc(l.product.image)}" alt=""><div><b>${esc(l.product.name)}</b><small>${esc(l.variant.wood)} · ${l.qty} ${l.qty === 1 ? 'unidade' : 'unidades'}</small><span>${money(l.total)}</span></div></div>`).join('');
    const per = method === 'pix' ? 1 : n;
    $('sum-rows').innerHTML = `<div class="srow"><span>Subtotal · ${count} ${count === 1 ? 'peça' : 'peças'}</span><span>${money(t.subtotal)}</span></div>
      ${t.discount ? `<div class="srow disc"><span>Desconto (${esc(coupon.code)})</span><span>− ${money(t.discount)}</span></div>` : ''}
      <div class="srow"><span>Entrega agendada</span><span>${quote ? money(quote.price) : 'Informe o CEP'}</span></div>
      ${quote ? `<div class="srow dim"><span>Para ${esc(quote.city || 'o seu CEP')}${quote.uf ? ', ' + esc(quote.uf) : ''} · CEP ${U.maskCEP(quote.cep)}</span></div>` : ''}
      <div class="stotal"><b>Total</b><strong>${money(t.total)}</strong></div>
      <p class="inst">${per === 1 ? 'À vista, sem juros' : `${per}x de ${money(t.total / per)} sem juros`}</p><p class="safe">${I('lock', 'ico-sm')} Seus dados e seu pagamento protegidos.</p>`;
    $('paynow').textContent = `Total a pagar: ${money(t.total)}`;
    $('paynote').textContent = method === 'pix'
      ? 'Ao confirmar, enviamos as instruções do Pix para o seu e-mail. A produção começa após a aprovação do pagamento.'
      : `Ao confirmar, seu cartão será cobrado em ${per}x de ${money(t.total / per)}. A produção começa após a aprovação do pagamento.`;
    const sel = $('installments'); const cur = sel.value || String(maxInst);
    sel.innerHTML = Array.from({ length: maxInst }, (_, i) => i + 1).map((k) => `<option value="${k}">${k}x de ${money(t.total / k)} sem juros</option>`).join('');
    sel.value = cur;
  }
  function renderDelivery() {
    const c = $('delivery-card'); c.classList.toggle('err', !quote);
    if (!quote) { c.innerHTML = `${I('checkc')}<div><b>Informe o CEP para calcular a entrega</b><p>Preencha o CEP na etapa anterior e mostramos o valor e o prazo.</p></div>`; return; }
    c.innerHTML = `${I('checkc')}<div><b>Entrega agendada <span>${money(quote.price)}</span></b><p>Produção: até ${Math.max(...lines.map((l) => l.product.lead_time_days))} dias úteis. Transporte: até ${quote.transpDays} dias úteis após a fabricação.</p>
      <p class="dk">${count > 1 ? `As ${count} peças chegam juntas. ` : ''}Entraremos em contato para agendar o recebimento.</p></div>`;
  }
  const refresh = () => { renderSummary(); renderDelivery(); };

  /* ----- pagamento ----- */
  document.querySelectorAll('.pay-opt').forEach((b) => b.addEventListener('click', () => {
    method = b.dataset.pay; document.querySelectorAll('.pay-opt').forEach((x) => x.setAttribute('aria-checked', x === b));
    $('card-fields').hidden = method === 'pix'; $('pix-box').hidden = method !== 'pix';
    $('pay-note').textContent = method === 'pix' ? 'Pix · à vista' : `Cartão de crédito · em até ${maxInst}x sem juros`; refresh();
  }));
  $('installments').addEventListener('change', renderSummary);

  /* ----- CEP: preenche endereço e calcula frete ----- */
  const cepIn = $('cep'); let lastCep = '';
  async function lookupCep() {
    const d = U.digits(cepIn.value); if (d.length !== 8 || d === lastCep) return; lastCep = d; U.setError(form, 'cep', '');
    try {
      const r = await Store.shippingQuote(d); quote = r; Store.saveCep(r);
      const fill = (id, v) => { const el = $(id); if (v && (!el.value || el.dataset.auto)) { el.value = v; el.dataset.auto = '1'; } };
      fill('street', r.street); fill('district', r.district); fill('city', r.city); fill('state', r.uf); refresh();
    } catch (e) { quote = null; lastCep = ''; U.setError(form, 'cep', e.message); refresh(); }
  }
  cepIn.addEventListener('input', () => { if (U.digits(cepIn.value).length === 8) lookupCep(); });
  ['street', 'district', 'city', 'state'].forEach((id) => $(id).addEventListener('input', (e) => delete e.target.dataset.auto));
  if (quote) { cepIn.value = U.maskCEP(quote.cep); lastCep = quote.cep; for (const [id, v] of [['street', quote.street], ['district', quote.district], ['city', quote.city], ['state', quote.uf]]) if (v) { $(id).value = v; $(id).dataset.auto = '1'; } }

  /* ----- conta ----- */
  async function syncUser() {
    user = await Store.auth.user(); const t = $('login-text'); $('login-hint').disabled = false;
    if (user) {
      t.textContent = `Olá, ${user.name.split(' ')[0]}! Preenchemos seus dados.`;
      if (!form.name.value) form.name.value = user.name || ''; if (!form.email.value) form.email.value = user.email || '';
      if (!form.cpf.value && user.cpf) form.cpf.value = U.maskCPF(user.cpf); if (!form.phone.value && user.phone) form.phone.value = U.maskPhone(user.phone);
    } else t.textContent = 'Já tem uma conta? Entre para preencher mais rápido.';
  }
  $('login-hint').addEventListener('click', () => { if (!user) Layout.openAuth('login'); else Layout.toast(`Você está conectado como ${user.email}.`); });
  window.addEventListener('auth:change', syncUser);
  U.bindMasks(); syncUser(); refresh();

  /* ----- envio ----- */
  const R = U.r; const req = R.required();
  const rules = () => ({
    name: [req, R.name()], email: [req, R.email()], cpf: [req, R.cpf()], phone: [req, R.phone()],
    cep: [req, R.cep()], street: [req], number: [req], district: [req], city: [req],
    state: [req, (v) => (UFS.includes(v.toUpperCase()) ? '' : 'Use a sigla do estado, ex.: SP.')],
    ...(method === 'cartao' ? {
      card: [req, (v) => (U.isCard(v) ? '' : 'Número de cartão inválido. Confira os dígitos.')],
      card_name: [req, R.min(3, 'Informe o nome como está no cartão.')],
      expiry: [req, (v) => (U.isExpiry(v) ? '' : 'Validade inválida. Use MM/AA e uma data futura.')],
      cvv: [req, (v) => (U.isCVV(v) ? '' : 'Código inválido (3 ou 4 números).')]
    } : {})
  });
  let sending = false;
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); if (sending) return;
    const alertBox = $('form-alert'); alertBox.hidden = true; U.clearErrors(form); $('terms-err').hidden = true;
    let ok = U.validate(form, rules());
    if (!form.elements.terms.checked) { $('terms-err').textContent = 'Para continuar, aceite os termos de compra.'; $('terms-err').hidden = false; ok = false; }
    if (!quote) { renderDelivery(); if (ok) U.setError(form, 'cep', 'Informe um CEP válido para calcular a entrega.'); ok = false; }
    if (!ok) { alertBox.textContent = 'Confira os campos destacados para continuar.'; alertBox.hidden = false; return; }

    sending = true; const btn = $('confirm'); const label = btn.innerHTML; btn.disabled = true; btn.textContent = 'Registrando seu pedido…';
    const v = Object.fromEntries(new FormData(form));
    const inst = method === 'pix' ? 1 : +v.installments;
    try {
      const order = await Store.createOrder({
        customer: { name: v.name.trim(), email: v.email.trim().toLowerCase(), cpf: U.digits(v.cpf), phone: U.digits(v.phone) },
        address: { cep: U.digits(v.cep), street: v.street.trim(), number: v.number.trim(), complement: (v.complement || '').trim(), district: v.district.trim(), city: v.city.trim(), state: v.state.trim().toUpperCase(), billing_same: !!form.elements.billing_same.checked },
        notes: (v.notes || '').trim(), payment_method: method, installments: inst, coupon: coupon ? coupon.code : null,
        items: lines.map((l) => ({ variant_id: l.variant.id, quantity: l.qty }))
        // Dados de cartão NÃO fazem parte do pedido: são usados só na etapa de pagamento (payment.js).
      });
      const pay = await Payment.charge({ order, method });   // com 'mock', apenas devolve a mensagem de "aguardando pagamento"
      Cart.clear(); Store.saveCoupon(null);
      ['card', 'card_name', 'expiry', 'cvv'].forEach((k) => { if (form.elements[k]) form.elements[k].value = ''; });
      showDone(order, pay, v);
    } catch (err) {
      alertBox.textContent = err.message || 'Não foi possível registrar o pedido. Tente novamente.'; alertBox.hidden = false; alertBox.scrollIntoView({ block: 'center' });
      sending = false; btn.disabled = false; btn.innerHTML = label;
    }
  });

  function showDone(order, pay, v) {
    const first = v.name.trim().split(' ')[0];
    $('co-root').innerHTML = `<div class="done"><span class="kicker" style="margin-top:56px">Pedido recebido</span><h1>Obrigado, ${esc(first)}.</h1>
      <p class="muted" style="font-size:16px">${esc(pay.message)}</p>
      <div class="box"><dl><dt>Número do pedido</dt><dd><b>${esc(order.number)}</b></dd><dt>Peças</dt><dd>${lines.map((l) => `${l.qty}× ${esc(l.product.name)}`).join(', ')}</dd>
        <dt>Entrega</dt><dd>${esc(v.street)}, ${esc(v.number)} · ${esc(v.city)}/${esc(v.state.toUpperCase())}</dd>
        <dt>Pagamento</dt><dd>${method === 'pix' ? 'Pix' : `Cartão em ${v.installments}x`} · aguardando confirmação</dd><dt>Total</dt><dd><b>${money(order.total)}</b></dd></dl></div>
      <p class="muted">Enviaremos o acompanhamento para <b>${esc(v.email)}</b>. A produção (até ${Math.max(...lines.map((l) => l.product.lead_time_days))} dias úteis) começa após a aprovação do pagamento.</p>
      <p style="margin-top:28px"><a class="btn" href="catalogo.html">Continuar escolhendo ${I('arrow', 'ico-sm')}</a></p></div>`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
})();
