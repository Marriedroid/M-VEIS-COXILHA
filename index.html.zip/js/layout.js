/* Elementos compartilhados: cabeçalho, rodapé, modais, avisos, favoritos e cartões de produto. */
(function () {
  const B = window.COXILHA_CONFIG.brand;
  const { esc, money } = U;

  /* ------------------------------------------------------------ Ícones */
  const P = {
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
    bag: '<path d="M5 8h14l-1 12H6L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
    arrow: '<path d="M7 17 17 7M8 7h9v9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="1"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    check: '<path d="m5 12 5 5 9-10"/>', checkc: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    chev: '<path d="m6 9 6 6 6-6"/>', close: '<path d="M6 6l12 12M18 6 6 18"/>', menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    hand: '<path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11m0-5.5a1.5 1.5 0 0 1 3 0V11m0-4a1.5 1.5 0 0 1 3 0v6c0 4-2.5 7-6 7-2.5 0-4-1.2-5.5-3.5L4 14.5a1.5 1.5 0 0 1 2.5-1.5L8 15"/>',
    leaf: '<path d="M12 20v-7M12 13c-4 0-6-3-6-7 4 0 6 2.5 6 7Zm0 0c0-4 2-6 6-6 0 4-2 6-6 6Z"/><path d="M8 20h8"/>',
    truck: '<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
    hammer: '<path d="m14 6 4 4M3 21l8-8M12 6l3-3 6 6-3 3-6-6Z"/>', tag: '<path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="8" cy="9" r="1.2"/>',
    ticket: '<path d="M3 8a2 2 0 0 0 0 4v4h18v-4a2 2 0 0 1 0-4V6H3v2Z"/><path d="M14 6v12" stroke-dasharray="2 2"/>',
    card: '<rect x="3" y="6" width="18" height="12" rx="1"/><path d="M3 10h18"/>', qr: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h3v3h-3zM20 14v6M14 20h3"/>',
    handheart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/><path d="m9 11 2 2 4-4"/>'
  };
  const I = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[n]}</svg>`;

  /* ------------------------------------------------------------ Aviso (toast) */
  function toast(msg, { type = 'ok', action } = {}) {
    let box = document.querySelector('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
    const t = document.createElement('div'); t.className = 'toast' + (type === 'err' ? ' err' : '');
    t.innerHTML = `<span>${esc(msg)}</span>` + (action ? `<a href="${esc(action.href)}">${esc(action.label)}</a>` : '');
    box.appendChild(t); setTimeout(() => t.remove(), action ? 5500 : 3800);
  }

  /* ------------------------------------------------------------ Cabeçalho e rodapé */
  const NAV = [
    { label: 'Móveis', href: 'catalogo.html', page: ['catalog', 'product'] },
    { label: 'Nossa essência', href: 'index.html#essencia' },
    { label: 'Materiais', href: 'index.html#materiais' },
    { label: 'Feito sob medida', open: 'quote' }
  ];
  const navHtml = (page) => NAV.map((n) => n.open
    ? `<button type="button" data-open="${n.open}">${n.label}</button>`
    : `<a href="${n.href}"${n.page && n.page.includes(page) ? ' aria-current="page"' : ''}>${n.label}</a>`).join('');

  function header(page, variant) {
    const logo = `<a class="logo" href="index.html" aria-label="${esc(B.name)} — página inicial"><b>${esc(B.wordmark)}</b><small>${esc(B.tagline)}</small></a>`;
    if (variant === 'checkout') {
      return `<div class="announce">Feito com cuidado. Comprado com tranquilidade.</div>
      <header class="header"><div class="wrap header-in">${logo}<div class="secure">${I('lock')}<span>Compra segura</span></div></div></header>`;
    }
    return `<div class="announce">Madeira natural. Tempo, cuidado e história.</div>
    <header class="header"><div class="wrap header-in">${logo.replace('class="logo"', 'class="logo"')}
      <nav class="nav" aria-label="Principal">${navHtml(page)}</nav>
      <div class="hicons">
        <button type="button" data-open="search" aria-label="Pesquisar">${I('search')}</button>
        <button type="button" data-open="account" aria-label="Minha conta" id="acct-btn">${I('user')}</button>
        <a href="carrinho.html" aria-label="Carrinho"${page === 'cart' ? ' aria-current="page"' : ''}>${I('bag')}<span class="cart-count" id="cart-count" hidden>0</span></a>
        <button type="button" class="menu-btn" id="menu-btn" aria-label="Abrir menu" aria-expanded="false" style="display:none">${I('menu')}</button>
      </div></div>
      <div class="drawer" id="drawer" hidden><nav aria-label="Menu móvel">${navHtml(page)}</nav></div></header>`;
  }

  function footer(variant) {
    if (variant === 'checkout') {
      return `<footer class="footer-min"><div class="co"><div class="row"><span>${esc(B.brandShort || 'Coxilha')} · ${esc(B.tagline)}</span>
        <span><button type="button" data-info="trocas">Trocas e devoluções</button> · <button type="button" data-info="privacidade">Privacidade</button> · <button type="button" data-info="privacidade">Termos de compra</button></span></div>
        <small>Loja conceitual. Dados, produtos e condições de compra ilustrativos. © 2026 ${esc(B.name)}.</small></div></footer>`;
    }
    return `<footer class="footer"><div class="wrap"><div class="footer-grid">
      <div><a class="logo" href="index.html"><b>${esc(B.wordmark)}</b></a>
        <p class="lead">Móveis com essência. Feitos para fazer parte da sua história.</p><span class="tag">Marcenaria autoral brasileira</span></div>
      <div><h4>Explore</h4><ul><li><a href="catalogo.html">Todos os móveis</a></li><li><a href="index.html#essencia">Nossa essência</a></li>
        <li><a href="index.html#materiais">Materiais e cuidados</a></li><li><button type="button" data-open="quote">Sob medida</button></li></ul></div>
      <div><h4>Podemos ajudar?</h4><ul><li><button type="button" data-info="entregas">Entregas e prazos</button></li><li><button type="button" data-info="trocas">Trocas e devoluções</button></li>
        <li><button type="button" data-info="privacidade">Privacidade e termos</button></li><li><button type="button" data-open="contact">Fale com a Coxilha</button></li></ul></div>
      <div><h4>Conversa de oficina</h4><ul><li><a href="mailto:${esc(B.email)}">${esc(B.email)}</a></li><li style="margin-top:14px">${esc(B.hours)}</li>
        <li style="margin-top:14px"><a class="gold" href="${esc(B.instagram)}" target="_blank" rel="noopener">Instagram ${I('arrow', 'ico-sm')}</a>&nbsp;&nbsp;&nbsp;<a class="gold" href="${esc(B.pinterest)}" target="_blank" rel="noopener">Pinterest ${I('arrow', 'ico-sm')}</a></li></ul></div>
      </div><div class="footer-base"><span>© 2026 ${esc(B.name)} · Móveis que ficam.</span><span>Loja conceitual — produtos e condições ilustrativos.</span></div></div></footer>`;
  }

  /* ------------------------------------------------------------ Diálogos */
  const dlgs = {};
  function dialog(id, html, { cls = '', onOpen } = {}) {
    let d = dlgs[id];
    if (!d) {
      d = document.createElement('dialog'); d.id = 'dlg-' + id; if (cls) d.className = cls; document.body.appendChild(d); dlgs[id] = d;
      d.addEventListener('click', (e) => { if (e.target === d) d.close(); });   // clique no fundo fecha
    }
    d.innerHTML = html;
    d.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => d.close()));
    U.bindMasks(d);
    if (!d.open) d.showModal();
    if (onOpen) onOpen(d);
    return d;
  }
  const closeBtn = `<button type="button" class="dlg-x" data-close aria-label="Fechar">${I('close')}</button>`;

  const fld = ({ name, label, type = 'text', ph = '', ac = '', mask = '', req = false, rows = 0 }) =>
    `<div class="field"><label for="f-${name}">${label}${req ? '' : ' <small class="muted">(opcional)</small>'}</label>${rows
      ? `<textarea id="f-${name}" name="${name}" placeholder="${esc(ph)}" rows="${rows}"></textarea>`
      : `<input id="f-${name}" name="${name}" type="${type}" placeholder="${esc(ph)}" autocomplete="${ac}"${mask ? ` data-mask="${mask}" inputmode="${mask === 'phone' || mask === 'cep' ? 'tel' : 'numeric'}"` : ''}>`}<p class="field-error" data-error-for="${name}" hidden></p></div>`;

  /* Envio genérico: desabilita o botão, mostra erro geral e chama o callback */
  function submit(form, rules, fn) {
    form.setAttribute('novalidate', '');
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); U.clearErrors(form);
      const old = form.querySelector('.form-alert'); if (old) old.remove();
      if (!U.validate(form, rules)) return;
      const btn = form.querySelector('button[type=submit]'); const label = btn.innerHTML; btn.disabled = true; btn.textContent = 'Enviando…';
      try { await fn(Object.fromEntries(new FormData(form))); }
      catch (err) { const a = document.createElement('div'); a.className = 'form-alert'; a.setAttribute('role', 'alert'); a.textContent = err.message || 'Algo deu errado. Tente novamente.'; form.prepend(a); }
      finally { btn.disabled = false; btn.innerHTML = label; }
    });
  }
  const success = (d, title, text, btn = 'Fechar') => {
    d.querySelector('.dlg').innerHTML = `${closeBtn}<div class="dlg-ok">${I('checkc')}<h2>${esc(title)}</h2><p>${esc(text)}</p><button type="button" class="btn btn-outline" data-close>${btn}</button></div>`;
    d.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => d.close()));
  };

  /* --- Login / cadastro --- */
  function openAuth(tab = 'login', after) {
    const html = `<div class="dlg">${closeBtn}<span class="kicker">Sua conta</span><h2>Entre para preencher mais rápido.</h2>
      <p class="lead">Salve favoritos e acompanhe seus pedidos.</p>
      <div class="tabs" role="tablist"><button type="button" role="tab" data-tab="login">Entrar</button><button type="button" role="tab" data-tab="signup">Criar conta</button></div>
      <form id="f-login" data-panel="login">
        ${fld({ name: 'email', label: 'E-mail', type: 'email', ph: 'nome@exemplo.com', ac: 'email', req: true })}
        ${fld({ name: 'password', label: 'Senha', type: 'password', ac: 'current-password', req: true })}
        <button class="btn" type="submit">Entrar ${I('arrow', 'ico-sm')}</button></form>
      <form id="f-signup" data-panel="signup" hidden>
        ${fld({ name: 'name', label: 'Nome completo', ph: 'Ana Silva', ac: 'name', req: true })}
        ${fld({ name: 'email', label: 'E-mail', type: 'email', ph: 'nome@exemplo.com', ac: 'email', req: true })}
        ${fld({ name: 'password', label: 'Senha (mínimo 8 caracteres)', type: 'password', ac: 'new-password', req: true })}
        <button class="btn" type="submit">Criar conta ${I('arrow', 'ico-sm')}</button></form></div>`;
    const d = dialog('auth', html);
    const setTab = (t) => { d.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', b.dataset.tab === t)); d.querySelectorAll('[data-panel]').forEach((f) => (f.hidden = f.dataset.panel !== t)); };
    d.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab))); setTab(tab);
    const R = U.r;
    submit(d.querySelector('#f-login'), { email: [R.required(), R.email()], password: [R.required()] }, async (v) => {
      await Store.auth.signIn(v); d.close(); toast('Bem-vinda de volta! Você entrou na sua conta.'); if (after) after();
    });
    submit(d.querySelector('#f-signup'), { name: [R.required(), R.name()], email: [R.required(), R.email()], password: [R.required(), R.min(8, 'A senha precisa ter ao menos 8 caracteres.')] }, async (v) => {
      const r = await Store.auth.signUp(v);
      if (r.needsConfirmation) success(d, 'Quase lá!', 'Enviamos um link de confirmação para o seu e-mail. Confirme para entrar.');
      else { d.close(); toast('Conta criada. Seja bem-vindo(a)!'); if (after) after(); }
    });
  }

  /* --- Conta (favoritos, pedidos, sair) --- */
  async function openAccount() {
    const u = await Store.auth.user();
    if (!u) return openAuth('login');
    const d = dialog('account', `<div class="dlg">${closeBtn}<span class="kicker">Minha conta</span><h2>Olá, ${esc(u.name.split(' ')[0])}.</h2><p class="lead">${esc(u.email)}</p>
      <div class="acct-sec"><h3>Favoritos</h3><div id="acct-favs" class="muted">Carregando…</div></div>
      <div class="acct-sec"><h3>Meus pedidos</h3><div id="acct-orders" class="muted">Carregando…</div></div>
      <button type="button" class="btn btn-outline" id="logout" style="margin-top:26px">Sair da conta</button></div>`);
    d.querySelector('#logout').addEventListener('click', async () => { await Store.auth.signOut(); d.close(); toast('Você saiu da conta.'); });
    const [ids, all, orders] = await Promise.all([Store.favorites.ids(), Store.allProducts(), Store.myOrders().catch(() => [])]);
    const favs = all.filter((p) => ids.includes(p.id));
    d.querySelector('#acct-favs').innerHTML = favs.length ? favs.map((p) => `<div class="mini"><img src="${esc(p.image)}" alt=""><a href="produto.html?slug=${esc(p.slug)}">${esc(p.name)}</a><span class="sp">${money(Store.minPrice(p))}</span></div>`).join('') : 'Você ainda não favoritou nenhuma peça.';
    const label = { aguardando_pagamento: 'Aguardando pagamento', pago: 'Pago', em_producao: 'Em produção', enviado: 'Enviado', entregue: 'Entregue', cancelado: 'Cancelado' };
    d.querySelector('#acct-orders').innerHTML = orders.length ? orders.map((o) => `<div class="mini"><div><b>${esc(o.number)}</b><br><small class="muted">${new Date(o.created_at).toLocaleDateString('pt-BR')} · ${esc(label[o.status] || o.status)}</small></div><span class="sp"><b style="color:var(--brown)">${money(o.total)}</b></span></div>`).join('') : 'Nenhum pedido por aqui ainda.';
  }

  /* --- Orçamento / contato --- */
  async function openRequest(kind, preset = {}) {
    const quote = kind === 'orcamento';
    const products = quote ? await Store.allProducts() : [];
    const html = `<div class="dlg">${closeBtn}<span class="kicker">${quote ? 'Feito sob medida' : 'Conversa de oficina'}</span>
      <h2>${quote ? 'Conte sobre o seu projeto.' : 'Fale com a Coxilha.'}</h2>
      <p class="lead">${quote ? 'Adaptações de medidas e acabamentos, com orçamento e prazo próprios. Respondemos por e-mail.' : `Dúvidas sobre medidas, acabamentos e entrega? ${esc(B.hours)}.`}</p>
      <form id="f-req"><div class="hp" aria-hidden="true"><label>Não preencha <input name="website" tabindex="-1" autocomplete="off"></label></div>
        ${fld({ name: 'name', label: 'Nome completo', ph: 'Ana Silva', ac: 'name', req: true })}
        ${fld({ name: 'email', label: 'E-mail', type: 'email', ph: 'nome@exemplo.com', ac: 'email', req: true })}
        ${fld({ name: 'phone', label: 'Celular com DDD', type: 'tel', ph: '(11) 99999-0000', ac: 'tel', mask: 'phone' })}
        ${quote ? `<div class="field"><label for="f-product">Peça de referência <small class="muted">(opcional)</small></label><div class="selwrap"><select id="f-product" name="product"><option value="">Projeto novo / outra peça</option>${products.map((p) => `<option value="${esc(p.slug)}"${preset.product === p.slug ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select>${I('chev')}</div></div>
          ${fld({ name: 'dimensions', label: 'Medidas desejadas', ph: 'Ex.: 200 × 100 × 76 cm' })}` : ''}
        ${fld({ name: 'message', label: 'Mensagem', ph: quote ? 'Conte o que você imagina: ambiente, uso, madeira, prazo…' : 'Como podemos ajudar?', req: true, rows: 4 })}
        <button class="btn" type="submit">Enviar ${I('arrow', 'ico-sm')}</button></form></div>`;
    const d = dialog('request', html);
    const u = await Store.auth.user(); const f = d.querySelector('#f-req');
    if (u) { f.name.value = u.name || ''; f.email.value = u.email || ''; }
    const R = U.r;
    submit(f, { name: [R.required(), R.name()], email: [R.required(), R.email()], phone: [R.phone()], message: [R.required(), R.min(10, 'Conte um pouco mais (mínimo 10 caracteres).')] }, async (v) => {
      if (v.website) return success(d, 'Mensagem enviada', 'Obrigado!');   // honeypot: bots preenchem, ignoramos em silêncio
      await Store.sendRequest(kind, { name: v.name, email: v.email, phone: v.phone, message: v.message, dimensions: v.dimensions, productSlug: v.product });
      success(d, quote ? 'Pedido de orçamento enviado' : 'Mensagem enviada', quote ? 'Recebemos seu projeto. Em breve a oficina responde por e-mail com orçamento e prazo.' : 'Recebemos sua mensagem. Respondemos no próximo dia útil.');
    });
  }

  /* --- Pesquisa --- */
  function openSearch() {
    const d = dialog('search', `<div class="dlg">${closeBtn}<span class="kicker">Pesquisar</span><h2>O que você procura para sua casa?</h2>
      <form id="f-search" style="margin-top:20px"><div class="field"><label class="sr-only" for="f-q">Pesquisar</label><input id="f-q" name="q" type="search" placeholder="Mesa, banco, cadeira, buffet…" autocomplete="off"></div>
      <button class="btn" type="submit">Buscar ${I('arrow', 'ico-sm')}</button></form></div>`);
    d.querySelector('#f-q').focus();
    d.querySelector('#f-search').addEventListener('submit', (e) => { e.preventDefault(); const q = d.querySelector('#f-q').value.trim(); location.href = 'catalogo.html' + (q ? '?q=' + encodeURIComponent(q) : ''); });
  }

  /* --- Políticas --- */
  const INFO = {
    entregas: ['Entregas e prazos', `<p>Cada peça é feita sob encomenda. A produção começa após a confirmação do pagamento e leva até 25 dias úteis.</p><p>Depois da fabricação, o transporte leva até 7 dias úteis, conforme o CEP. Quando o pedido tem mais de uma peça, enviamos tudo junto, assim que todas estiverem prontas.</p><p>Entramos em contato para agendar o recebimento. Antes da compra, confira acessos, portas e elevadores.</p>`],
    trocas: ['Trocas e devoluções', `<p>Nas compras online, você tem 7 dias após o recebimento para solicitar o arrependimento, conforme o Código de Defesa do Consumidor.</p><p>Se a peça chegar com avaria, avise a oficina assim que receber, com fotos, e resolvemos com você. Peças sob medida têm condições próprias, combinadas no orçamento.</p><p>Fale com a oficina: <a href="mailto:${esc(B.email)}" style="text-decoration:underline">${esc(B.email)}</a>.</p>`],
    privacidade: ['Privacidade e termos', `<h3>Seus dados</h3><p>Usamos seus dados para processar o pedido, entregar a peça, atender você e, se autorizar, enviar novidades. Dados completos de cartão não são armazenados pela loja.</p><p>Você pode pedir acesso, correção ou exclusão dos seus dados a qualquer momento, em ${esc(B.email)}.</p><h3>Termos de compra</h3><p>A produção começa após a aprovação do pagamento. O prazo de fabricação (até 25 dias úteis) e o de transporte são informados no pedido. Madeira natural tem variações de tom e veio, o que torna cada peça única.</p>`]
  };
  function openInfo(key) {
    const [t, body] = INFO[key]; dialog('info', `<div class="dlg info-body">${closeBtn}<span class="kicker">Podemos ajudar</span><h2>${t}</h2>${body}<button type="button" class="btn btn-outline" data-close style="margin-top:14px">Entendi</button></div>`);
  }

  function lightbox(src, alt) {
    dialog('lightbox', `<button type="button" class="dlg-x" data-close aria-label="Fechar">${I('close')}</button><img src="${esc(src)}" alt="${esc(alt)}">`, { cls: 'lightbox' });
  }

  /* ------------------------------------------------------------ Cartão de produto */
  function productCard(p, { home = false } = {}) {
    const v = p.variants[0]; const href = 'produto.html?slug=' + encodeURIComponent(p.slug);
    return `<article class="pcard"><a class="pcard-img" href="${href}"><img src="${esc(home ? p.home_image : p.image)}" alt="${esc(p.name)}" loading="lazy"></a>
      <button type="button" class="fav" data-fav="${esc(p.id)}" aria-pressed="false" aria-label="Favoritar ${esc(p.name)}">${I('heart')}</button>
      <div class="pcard-top"><h3><a href="${href}">${esc(p.name)}</a></h3>
        <button type="button" class="quick" data-quick="${esc(p.slug)}" aria-label="Adicionar ${esc(p.name)} ao carrinho">${I('plus')}</button></div>
      <p class="spec">${esc(v.wood)} · ${esc(v.dimensions)}</p><p class="price">${p.variants.length > 1 ? 'A partir de ' : ''}${money(Store.minPrice(p))}</p>
      <p class="inst">Em até ${p.installments}x sem juros</p></article>`;
  }

  /* ------------------------------------------------------------ Estado compartilhado */
  async function syncFavs(root = document) {
    const ids = await Store.favorites.ids();
    root.querySelectorAll('[data-fav]').forEach((b) => b.setAttribute('aria-pressed', ids.includes(b.dataset.fav)));
  }
  function updateBadge() {
    const n = Cart.count(); const el = document.getElementById('cart-count'); if (!el) return;
    el.textContent = n; el.hidden = n === 0;
  }
  async function updateUser() {
    const b = document.getElementById('acct-btn'); if (!b) return;
    const u = await Store.auth.user(); b.setAttribute('aria-label', u ? `Minha conta (${u.name})` : 'Entrar ou criar conta'); b.title = u ? u.name : 'Entrar';
  }
  function accordion(root) {
    root.addEventListener('click', (e) => {
      const q = e.target.closest('.acc-q'); if (!q) return; const item = q.parentElement; const open = !item.classList.contains('open');
      root.querySelectorAll('.acc-item').forEach((i) => { i.classList.remove('open'); i.querySelector('.acc-q').setAttribute('aria-expanded', 'false'); });
      if (open) { item.classList.add('open'); q.setAttribute('aria-expanded', 'true'); }
    });
  }

  function init({ page, variant } = {}) {
    document.getElementById('app-header').innerHTML = header(page, variant);
    document.getElementById('app-footer').innerHTML = footer(variant);
    const menu = document.getElementById('menu-btn'), drawer = document.getElementById('drawer');
    if (menu) menu.addEventListener('click', () => { const o = drawer.hidden; drawer.hidden = !o; menu.setAttribute('aria-expanded', o); });

    document.addEventListener('click', async (e) => {
      const o = e.target.closest('[data-open]'); const inf = e.target.closest('[data-info]');
      const fav = e.target.closest('[data-fav]'); const quick = e.target.closest('[data-quick]');
      if (o) {
        e.preventDefault(); const k = o.dataset.open;
        ({ search: openSearch, account: openAccount, login: () => openAuth('login'), quote: () => openRequest('orcamento', { product: o.dataset.product }), contact: () => openRequest('contato') })[k]();
        if (drawer) drawer.hidden = true;
      } else if (inf) { e.preventDefault(); openInfo(inf.dataset.info); }
      else if (fav) {
        e.preventDefault(); fav.disabled = true;
        try { const on = await Store.favorites.toggle(fav.dataset.fav); toast(on ? 'Peça adicionada aos favoritos.' : 'Peça removida dos favoritos.'); }
        catch (err) { toast(err.message, { type: 'err' }); } finally { fav.disabled = false; }
      } else if (quick) {
        e.preventDefault(); const p = await Store.product(quick.dataset.quick); if (!p) return;
        if (p.variants.length > 1) { location.href = 'produto.html?slug=' + p.slug; return; }
        Cart.add(p.slug, p.variants[0].id, 1); toast(`${p.name} adicionada ao carrinho.`, { action: { href: 'carrinho.html', label: 'Ver carrinho' } });
        quick.classList.add('done'); setTimeout(() => quick.classList.remove('done'), 1200);
      }
    });
    window.addEventListener('cart:change', updateBadge);
    window.addEventListener('favorites:change', () => syncFavs());
    window.addEventListener('auth:change', () => { updateUser(); syncFavs(); });
    window.addEventListener('storage', () => { updateBadge(); syncFavs(); });
    updateBadge(); updateUser();
  }

  window.Layout = { init, I, toast, productCard, syncFavs, accordion, openAuth, openRequest, openInfo, lightbox, submit };
})();
