/*
 * Camada de pagamento. O site NUNCA envia nem armazena número de cartão, validade ou CVV.
 *
 * provider 'mock' (padrão): registra o pedido como "aguardando pagamento" e devolve instruções
 * genéricas. Nenhuma cobrança é feita.
 *
 * Para cobrar de verdade, implemente um provedor abaixo (Mercado Pago, Pagar.me, Stripe, Asaas...):
 *  - Cartão: use o SDK do gateway no navegador para TOKENIZAR o cartão (os dados vão direto ao gateway)
 *    e envie só o token a uma Supabase Edge Function que cria a cobrança com a chave secreta.
 *  - Pix: a Edge Function cria a cobrança e devolve o "copia e cola"/QR Code para exibir ao cliente.
 *  - Um webhook do gateway atualiza orders.status para 'pago' (veja README.md).
 */
(function () {
  const CFG = window.COXILHA_CONFIG.payment;
  const providers = {
    mock: {
      async charge({ order, method }) {
        return {
          status: 'aguardando_pagamento',
          message: method === 'pix'
            ? 'Assim que o pagamento via Pix estiver habilitado, enviaremos o código para o seu e-mail. Seu pedido já está reservado.'
            : 'Seu pedido foi registrado. A confirmação do pagamento será enviada ao seu e-mail e a produção começa após a aprovação.'
        };
      }
    }
    // mercadopago: { async charge({ order, method, card }) { ... } },
  };
  window.Payment = {
    provider: CFG.provider,
    async charge(args) {
      const p = providers[CFG.provider];
      if (!p) throw new Error('Pagamento ainda não configurado. Fale com a oficina para finalizar seu pedido.');
      return p.charge(args);
    }
  };
})();
