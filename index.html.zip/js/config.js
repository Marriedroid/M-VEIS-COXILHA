/*
 * Configuração central da loja Móveis Coxilha.
 * Todos os valores que podem mudar entre ambientes ficam aqui.
 */
window.COXILHA_CONFIG = {
  brand: {
    name: 'Móveis Coxilha',
    wordmark: 'coxilha.',            // texto do logotipo (mesmo estilo do layout original)
    tagline: 'Marcenaria do essencial',
    email: 'oi@moveiscoxilha.com.br', // TROQUE pelo e-mail real da loja
    hours: 'Seg. a sex., das 9h às 18h',
    instagram: 'https://www.instagram.com/',
    pinterest: 'https://www.pinterest.com/'
  },

  /*
   * Supabase. Deixe em branco para usar o MODO LOCAL (dados no navegador),
   * útil para testar sem banco. Para ativar, preencha com os dados de
   * Project Settings > API do seu projeto Supabase.
   * A chave "anon" é pública por design; a segurança vem das políticas RLS
   * definidas em supabase/schema.sql. NUNCA coloque a chave service_role aqui.
   */
  supabase: {
    url: '',      // ex.: 'https://abcdxyz.supabase.co'
    anonKey: ''   // ex.: 'eyJhbGciOi...'
  },

  /*
   * Frete. Provedor 'table' usa a tabela shipping_rates (Supabase) ou a
   * tabela abaixo (modo local). Para cotação em tempo real (Correios,
   * Melhor Envio, Frenet...) é preciso um token e uma Edge Function/servidor
   * próprio: veja README.md, seção "Integrações".
   */
  shipping: {
    provider: 'table',
    productionDaysMax: 25,
    transportDaysMax: 7,
    // Valores de exemplo (SP vem do layout; os demais são PLACEHOLDERS a ajustar).
    localRates: { SP: 180, DEFAULT: 280 }
  },

  /*
   * Pagamento. 'mock' apenas registra o pedido como "aguardando pagamento".
   * Nenhum dado de cartão é enviado ou armazenado. Para cobrar de verdade,
   * veja README.md (Mercado Pago, Pagar.me, Stripe, Asaas...).
   */
  payment: {
    provider: 'mock',
    maxInstallments: 10
  },

  // Cupons do MODO LOCAL (apenas teste). Em produção, cadastre na tabela public.coupons do Supabase.
  localCoupons: { TESTE10: { kind: 'percent', value: 10, min: 0 } },

  cepLookupUrl: 'https://viacep.com.br/ws/{cep}/json/'
};
